// Configuration file to handle environment variables
const config = {
  // API Configuration
  API_BASE_URL: import.meta.env.VITE_API_BASE_URL,

  // Cache Configuration
  CACHE_TIMEOUT: Number.parseInt(import.meta.env.VITE_CACHE_TIMEOUT) || 5 * 60 * 1000, // 5 minutes default
  DEFAULT_PAGE_SIZE: Number.parseInt(import.meta.env.VITE_DEFAULT_PAGE_SIZE) || 10,

  // Feature flags
  ENABLE_CACHING: import.meta.env.VITE_ENABLE_CACHING === "true",
  ENABLE_OFFLINE_MODE: import.meta.env.VITE_ENABLE_OFFLINE_MODE === "true",

  // Payment Configuration (if needed)
  PAYSTACK_PUBLIC_KEY: import.meta.env.VITE_PAYSTACK_PUBLIC_KEY,
  STRIPE_PUBLIC_KEY: import.meta.env.VITE_STRIPE_PUBLIC_KEY,

  // Environment info
  IS_DEVELOPMENT: import.meta.env.DEV,
  IS_PRODUCTION: import.meta.env.PROD,
  MODE: import.meta.env.MODE,
}

// Validation function to ensure required environment variables are set
const validateConfig = () => {
  const requiredVars = ["VITE_API_BASE_URL"]
  const missing = requiredVars.filter((varName) => !import.meta.env[varName])
}

// Validate config
validateConfig()

export default config
