"use client"
import { useState } from "react"
import { useAuthStore } from "../store/authStore"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import {
  User,
  Bell,
  Shield,
  Palette,
  Volume2,
  Download,
  Smartphone,
  Monitor,
  Moon,
  Sun,
  Save,
  Loader2,
} from "lucide-react"
import { toast } from "sonner"

export default function SettingsPage() {
  const { user } = useAuthStore()
  const [isUpdating, setIsUpdating] = useState(false)

  // Account settings
  const [accountSettings, setAccountSettings] = useState({
    name: user?.name || "John Doe",
    email: user?.email || "john@example.com",
    language: "en",
    timezone: "Africa/Lagos",
  })

  // Notification settings
  const [notificationSettings, setNotificationSettings] = useState({
    pushNotifications: true,
    emailNotifications: true,
    newMessages: true,
    newPodcasts: true,
    liveStreams: true,
    specialEvents: true,
    weeklyDigest: false,
    soundEnabled: true,
  })

  // Privacy settings
  const [privacySettings, setPrivacySettings] = useState({
    profileVisibility: "public",
    showListeningHistory: true,
    allowRecommendations: true,
    dataCollection: true,
    analyticsOptIn: false,
  })

  // Appearance settings
  const [appearanceSettings, setAppearanceSettings] = useState({
    theme: "system",
    fontSize: "medium",
    compactMode: false,
    showThumbnails: true,
    animationsEnabled: true,
  })

  // Audio settings
  const [audioSettings, setAudioSettings] = useState({
    audioQuality: "high",
    autoPlay: true,
    crossfade: false,
    normalizeVolume: true,
    defaultVolume: 80,
    bufferSize: "medium",
  })

  // Download settings
  const [downloadSettings, setDownloadSettings] = useState({
    downloadQuality: "high",
    wifiOnlyDownloads: true,
    autoDownload: false,
    downloadLocation: "internal",
    maxDownloads: 50,
  })

  const handleAccountChange = (key, value) => {
    setAccountSettings((prev) => ({ ...prev, [key]: value }))
  }

  const handleNotificationChange = (key, value) => {
    setNotificationSettings((prev) => ({ ...prev, [key]: value }))
  }

  const handlePrivacyChange = (key, value) => {
    setPrivacySettings((prev) => ({ ...prev, [key]: value }))
  }

  const handleAppearanceChange = (key, value) => {
    setAppearanceSettings((prev) => ({ ...prev, [key]: value }))
  }

  const handleAudioChange = (key, value) => {
    setAudioSettings((prev) => ({ ...prev, [key]: value }))
  }

  const handleDownloadChange = (key, value) => {
    setDownloadSettings((prev) => ({ ...prev, [key]: value }))
  }

  const handleSaveSettings = async () => {
    setIsUpdating(true)
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))
      toast.success("Settings saved successfully!")
    } catch (error) {
      toast.error("Failed to save settings")
    } finally {
      setIsUpdating(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Settings</h1>
        <p className="text-muted-foreground">Customize your experience</p>
      </div>

      <Tabs defaultValue="account" className="w-full">
        <TabsList className="mb-8 grid grid-cols-3 md:grid-cols-6 w-full">
          <TabsTrigger value="account">
            <User className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Account</span>
          </TabsTrigger>
          <TabsTrigger value="notifications">
            <Bell className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Notifications</span>
          </TabsTrigger>
          <TabsTrigger value="privacy">
            <Shield className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Privacy</span>
          </TabsTrigger>
          <TabsTrigger value="appearance">
            <Palette className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Appearance</span>
          </TabsTrigger>
          <TabsTrigger value="audio">
            <Volume2 className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Audio</span>
          </TabsTrigger>
          <TabsTrigger value="downloads">
            <Download className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Downloads</span>
          </TabsTrigger>
        </TabsList>

        {/* Account Settings */}
        <TabsContent value="account">
          <Card className="bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70">
            <CardHeader>
              <CardTitle>Account Information</CardTitle>
              <CardDescription>Manage your account details and preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    value={accountSettings.name}
                    onChange={(e) => handleAccountChange("name", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    value={accountSettings.email}
                    onChange={(e) => handleAccountChange("email", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="language">Language</Label>
                  <Select
                    value={accountSettings.language}
                    onValueChange={(value) => handleAccountChange("language", value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="es">Español</SelectItem>
                      <SelectItem value="fr">Français</SelectItem>
                      <SelectItem value="de">Deutsch</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="timezone">Timezone</Label>
                  <Select
                    value={accountSettings.timezone}
                    onValueChange={(value) => handleAccountChange("timezone", value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Africa/Lagos">West Africa Time (WAT)</SelectItem>
                      <SelectItem value="America/New_York">Eastern Time (ET)</SelectItem>
                      <SelectItem value="Europe/London">Greenwich Mean Time (GMT)</SelectItem>
                      <SelectItem value="Asia/Tokyo">Japan Standard Time (JST)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notification Settings */}
        <TabsContent value="notifications">
          <Card className="bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70">
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
              <CardDescription>Choose how you want to be notified about updates and new content</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Push Notifications</h3>
                    <p className="text-sm text-muted-foreground">Receive notifications on your device</p>
                  </div>
                  <Switch
                    checked={notificationSettings.pushNotifications}
                    onCheckedChange={(checked) => handleNotificationChange("pushNotifications", checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Email Notifications</h3>
                    <p className="text-sm text-muted-foreground">Receive notifications via email</p>
                  </div>
                  <Switch
                    checked={notificationSettings.emailNotifications}
                    onCheckedChange={(checked) => handleNotificationChange("emailNotifications", checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">New Messages</h3>
                    <p className="text-sm text-muted-foreground">Get notified when new messages are added</p>
                  </div>
                  <Switch
                    checked={notificationSettings.newMessages}
                    onCheckedChange={(checked) => handleNotificationChange("newMessages", checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">New Podcasts</h3>
                    <p className="text-sm text-muted-foreground">Get notified when new podcast episodes are released</p>
                  </div>
                  <Switch
                    checked={notificationSettings.newPodcasts}
                    onCheckedChange={(checked) => handleNotificationChange("newPodcasts", checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Live Streams</h3>
                    <p className="text-sm text-muted-foreground">Get notified when live streams start</p>
                  </div>
                  <Switch
                    checked={notificationSettings.liveStreams}
                    onCheckedChange={(checked) => handleNotificationChange("liveStreams", checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Special Events</h3>
                    <p className="text-sm text-muted-foreground">Get notified about upcoming special events</p>
                  </div>
                  <Switch
                    checked={notificationSettings.specialEvents}
                    onCheckedChange={(checked) => handleNotificationChange("specialEvents", checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Weekly Digest</h3>
                    <p className="text-sm text-muted-foreground">Receive weekly email digest of new content</p>
                  </div>
                  <Switch
                    checked={notificationSettings.weeklyDigest}
                    onCheckedChange={(checked) => handleNotificationChange("weeklyDigest", checked)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Privacy Settings */}
        <TabsContent value="privacy">
          <Card className="bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70">
            <CardHeader>
              <CardTitle>Privacy & Security</CardTitle>
              <CardDescription>Control your privacy and data sharing preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Profile Visibility</Label>
                  <Select
                    value={privacySettings.profileVisibility}
                    onValueChange={(value) => handlePrivacyChange("profileVisibility", value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="public">Public</SelectItem>
                      <SelectItem value="friends">Friends Only</SelectItem>
                      <SelectItem value="private">Private</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Show Listening History</h3>
                    <p className="text-sm text-muted-foreground">Allow others to see what you've been listening to</p>
                  </div>
                  <Switch
                    checked={privacySettings.showListeningHistory}
                    onCheckedChange={(checked) => handlePrivacyChange("showListeningHistory", checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Allow Recommendations</h3>
                    <p className="text-sm text-muted-foreground">
                      Use your listening data to provide personalized recommendations
                    </p>
                  </div>
                  <Switch
                    checked={privacySettings.allowRecommendations}
                    onCheckedChange={(checked) => handlePrivacyChange("allowRecommendations", checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Data Collection</h3>
                    <p className="text-sm text-muted-foreground">
                      Allow collection of usage data to improve the service
                    </p>
                  </div>
                  <Switch
                    checked={privacySettings.dataCollection}
                    onCheckedChange={(checked) => handlePrivacyChange("dataCollection", checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Analytics Opt-in</h3>
                    <p className="text-sm text-muted-foreground">
                      Share anonymous analytics data to help improve the app
                    </p>
                  </div>
                  <Switch
                    checked={privacySettings.analyticsOptIn}
                    onCheckedChange={(checked) => handlePrivacyChange("analyticsOptIn", checked)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Appearance Settings */}
        <TabsContent value="appearance">
          <Card className="bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70">
            <CardHeader>
              <CardTitle>Appearance & Display</CardTitle>
              <CardDescription>Customize how the app looks and feels</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Theme</Label>
                  <Select
                    value={appearanceSettings.theme}
                    onValueChange={(value) => handleAppearanceChange("theme", value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">
                        <div className="flex items-center">
                          <Sun className="mr-2 h-4 w-4" />
                          Light
                        </div>
                      </SelectItem>
                      <SelectItem value="dark">
                        <div className="flex items-center">
                          <Moon className="mr-2 h-4 w-4" />
                          Dark
                        </div>
                      </SelectItem>
                      <SelectItem value="system">
                        <div className="flex items-center">
                          <Monitor className="mr-2 h-4 w-4" />
                          System
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Separator />
                <div className="space-y-2">
                  <Label>Font Size</Label>
                  <Select
                    value={appearanceSettings.fontSize}
                    onValueChange={(value) => handleAppearanceChange("fontSize", value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="small">Small</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="large">Large</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Compact Mode</h3>
                    <p className="text-sm text-muted-foreground">Use a more compact layout to fit more content</p>
                  </div>
                  <Switch
                    checked={appearanceSettings.compactMode}
                    onCheckedChange={(checked) => handleAppearanceChange("compactMode", checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Show Thumbnails</h3>
                    <p className="text-sm text-muted-foreground">Display thumbnail images for content</p>
                  </div>
                  <Switch
                    checked={appearanceSettings.showThumbnails}
                    onCheckedChange={(checked) => handleAppearanceChange("showThumbnails", checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Animations</h3>
                    <p className="text-sm text-muted-foreground">Enable smooth animations and transitions</p>
                  </div>
                  <Switch
                    checked={appearanceSettings.animationsEnabled}
                    onCheckedChange={(checked) => handleAppearanceChange("animationsEnabled", checked)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Audio Settings */}
        <TabsContent value="audio">
          <Card className="bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70">
            <CardHeader>
              <CardTitle>Audio & Playback</CardTitle>
              <CardDescription>Configure audio quality and playback preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Audio Quality</Label>
                  <Select
                    value={audioSettings.audioQuality}
                    onValueChange={(value) => handleAudioChange("audioQuality", value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low (96 kbps)</SelectItem>
                      <SelectItem value="medium">Medium (128 kbps)</SelectItem>
                      <SelectItem value="high">High (320 kbps)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Separator />
                <div className="space-y-2">
                  <Label>Default Volume ({audioSettings.defaultVolume}%)</Label>
                  <Slider
                    value={[audioSettings.defaultVolume]}
                    max={100}
                    step={1}
                    onValueChange={(value) => handleAudioChange("defaultVolume", value[0])}
                    className="w-full"
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Auto Play</h3>
                    <p className="text-sm text-muted-foreground">Automatically play next item in queue</p>
                  </div>
                  <Switch
                    checked={audioSettings.autoPlay}
                    onCheckedChange={(checked) => handleAudioChange("autoPlay", checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Crossfade</h3>
                    <p className="text-sm text-muted-foreground">Smoothly transition between tracks</p>
                  </div>
                  <Switch
                    checked={audioSettings.crossfade}
                    onCheckedChange={(checked) => handleAudioChange("crossfade", checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Normalize Volume</h3>
                    <p className="text-sm text-muted-foreground">Keep volume consistent across different tracks</p>
                  </div>
                  <Switch
                    checked={audioSettings.normalizeVolume}
                    onCheckedChange={(checked) => handleAudioChange("normalizeVolume", checked)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Download Settings */}
        <TabsContent value="downloads">
          <Card className="bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70">
            <CardHeader>
              <CardTitle>Download Preferences</CardTitle>
              <CardDescription>Manage how content is downloaded and stored</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Download Quality</Label>
                  <Select
                    value={downloadSettings.downloadQuality}
                    onValueChange={(value) => handleDownloadChange("downloadQuality", value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low (96 kbps)</SelectItem>
                      <SelectItem value="medium">Medium (128 kbps)</SelectItem>
                      <SelectItem value="high">High (320 kbps)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">WiFi Only Downloads</h3>
                    <p className="text-sm text-muted-foreground">Only download content when connected to WiFi</p>
                  </div>
                  <Switch
                    checked={downloadSettings.wifiOnlyDownloads}
                    onCheckedChange={(checked) => handleDownloadChange("wifiOnlyDownloads", checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Auto Download</h3>
                    <p className="text-sm text-muted-foreground">
                      Automatically download new episodes of subscribed podcasts
                    </p>
                  </div>
                  <Switch
                    checked={downloadSettings.autoDownload}
                    onCheckedChange={(checked) => handleDownloadChange("autoDownload", checked)}
                  />
                </div>
                <Separator />
                <div className="space-y-2">
                  <Label>Download Location</Label>
                  <Select
                    value={downloadSettings.downloadLocation}
                    onValueChange={(value) => handleDownloadChange("downloadLocation", value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="internal">
                        <div className="flex items-center">
                          <Smartphone className="mr-2 h-4 w-4" />
                          Internal Storage
                        </div>
                      </SelectItem>
                      <SelectItem value="external">
                        <div className="flex items-center">
                          <Download className="mr-2 h-4 w-4" />
                          External Storage
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Separator />
                <div className="space-y-2">
                  <Label>Maximum Downloads ({downloadSettings.maxDownloads})</Label>
                  <Slider
                    value={[downloadSettings.maxDownloads]}
                    max={100}
                    min={10}
                    step={5}
                    onValueChange={(value) => handleDownloadChange("maxDownloads", value[0])}
                    className="w-full"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Save Button */}
      <div className="mt-8 flex justify-end">
        <Button onClick={handleSaveSettings} disabled={isUpdating}>
          {isUpdating ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              Save Settings
            </>
          )}
        </Button>
      </div>
    </div>
  )
}
