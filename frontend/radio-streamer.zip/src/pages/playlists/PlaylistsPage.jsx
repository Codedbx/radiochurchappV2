"use client"
import { useState } from "react"
import { Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Search, ListMusic, Play, Plus, Heart, Clock, Filter, Star, Users, Lock } from "lucide-react"
import { useCreatePlaylist } from "../../hooks/usePlaylists"
import { toast } from "sonner"

export default function PlaylistsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isCreatePlaylistOpen, setIsCreatePlaylistOpen] = useState(false)
  const [newPlaylistName, setNewPlaylistName] = useState("")
  const [newPlaylistDescription, setNewPlaylistDescription] = useState("")
  const [isCreatingPlaylist, setIsCreatingPlaylist] = useState(false)

  const createPlaylist = useCreatePlaylist()

  // Sample playlists data
  const playlists = [
    {
      id: 1,
      title: "Worship Anthems",
      description: "A collection of powerful worship songs to uplift your spirit and draw you closer to God.",
      image: "/images/house-exterior.jpg",
      count: 15,
      creator: "Admin",
      isPublic: true,
      likes: 234,
      plays: 1250,
      createdAt: "2023-07-15",
    },
    {
      id: 2,
      title: "Healing Declarations",
      description: "Messages and confessions for divine health and healing from various ministers.",
      image: "/images/house-exterior.jpg",
      count: 10,
      creator: "Pastor Sarah",
      isPublic: true,
      likes: 189,
      plays: 890,
      createdAt: "2023-07-20",
    },
    {
      id: 3,
      title: "Prosperity Teachings",
      description: "Unlock the principles of financial abundance and success through biblical teachings.",
      image: "/images/house-exterior.jpg",
      count: 8,
      creator: "Pastor Michael",
      isPublic: true,
      likes: 156,
      plays: 675,
      createdAt: "2023-07-25",
    },
    {
      id: 4,
      title: "Youth Empowerment",
      description: "Inspiring messages for young people to live victoriously and fulfill their purpose.",
      image: "/images/house-exterior.jpg",
      count: 12,
      creator: "Pastor Grace",
      isPublic: true,
      likes: 298,
      plays: 1100,
      createdAt: "2023-08-01",
    },
    {
      id: 5,
      title: "Faith Builders",
      description: "Messages that strengthen and build your faith for every situation in life.",
      image: "/images/house-exterior.jpg",
      count: 18,
      creator: "Pastor David",
      isPublic: true,
      likes: 345,
      plays: 1580,
      createdAt: "2023-08-05",
    },
    {
      id: 6,
      title: "Prayer Warriors",
      description: "Powerful teachings on prayer and spiritual warfare to equip the saints.",
      image: "/images/house-exterior.jpg",
      count: 14,
      creator: "Pastor John",
      isPublic: true,
      likes: 267,
      plays: 920,
      createdAt: "2023-08-10",
    },
  ]

  // Featured playlists
  const featuredPlaylists = playlists.slice(0, 3)

  // Filter playlists based on search term
  const filteredPlaylists = playlists.filter(
    (playlist) =>
      playlist.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      playlist.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      playlist.creator.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleCreatePlaylist = async () => {
    if (!newPlaylistName.trim()) return

    setIsCreatingPlaylist(true)
    try {
      await createPlaylist.mutateAsync({
        title: newPlaylistName,
        description: newPlaylistDescription,
        isPublic: false,
      })

      setNewPlaylistName("")
      setNewPlaylistDescription("")
      setIsCreatePlaylistOpen(false)
      toast.success("Playlist created successfully!")
    } catch (error) {
      toast.error("Failed to create playlist")
    } finally {
      setIsCreatingPlaylist(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold mb-2">Playlists</h1>
          <p className="text-muted-foreground">Curated collections of inspiring content</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search playlists..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4"
            />
          </div>
          <Dialog open={isCreatePlaylistOpen} onOpenChange={setIsCreatePlaylistOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Create Playlist
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Playlist</DialogTitle>
                <DialogDescription>Create a new playlist to organize your favorite content.</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="playlist-name">Playlist Name</Label>
                  <Input
                    id="playlist-name"
                    value={newPlaylistName}
                    onChange={(e) => setNewPlaylistName(e.target.value)}
                    placeholder="Enter playlist name..."
                  />
                </div>
                <div>
                  <Label htmlFor="playlist-description">Description (Optional)</Label>
                  <Textarea
                    id="playlist-description"
                    value={newPlaylistDescription}
                    onChange={(e) => setNewPlaylistDescription(e.target.value)}
                    placeholder="Enter playlist description..."
                    rows={3}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCreatePlaylistOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreatePlaylist} disabled={!newPlaylistName.trim() || isCreatingPlaylist}>
                  {isCreatingPlaylist ? "Creating..." : "Create Playlist"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <TabsList>
            <TabsTrigger value="all">All Playlists</TabsTrigger>
            <TabsTrigger value="featured">Featured</TabsTrigger>
            <TabsTrigger value="popular">Popular</TabsTrigger>
            <TabsTrigger value="recent">Recent</TabsTrigger>
          </TabsList>

          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
        </div>

        {/* Featured Playlists */}
        <TabsContent value="featured" className="mt-0">
          <div className="grid grid-cols-1 gap-6 mb-8">
            {featuredPlaylists.map((playlist) => (
              <Card
                key={playlist.id}
                className="overflow-hidden bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70"
              >
                <div className="flex flex-col md:flex-row">
                  <div className="relative md:w-1/3">
                    <img
                      src={playlist.image || "/placeholder.svg"}
                      alt={playlist.title}
                      className="w-full h-48 md:h-full object-cover"
                    />
                    <Badge className="absolute top-4 left-4 bg-primary">Featured</Badge>
                    <div className="absolute inset-0 bg-black/30 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Button size="icon" variant="secondary" className="rounded-full h-16 w-16">
                        <Play className="h-8 w-8 ml-1" />
                      </Button>
                    </div>
                  </div>
                  <div className="p-6 md:w-2/3">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center">
                        <ListMusic className="h-5 w-5 text-primary mr-2" />
                        <h3 className="text-2xl font-bold">{playlist.title}</h3>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-red-400">
                          <Heart className="h-5 w-5" />
                        </Button>
                      </div>
                    </div>
                    <p className="text-muted-foreground mb-4">Created by {playlist.creator}</p>
                    <p className="mb-4">{playlist.description}</p>
                    <div className="flex items-center text-sm text-muted-foreground mb-4">
                      <span className="mr-4">{playlist.count} messages</span>
                      <span className="mr-4">{playlist.likes} likes</span>
                      <span>{playlist.plays} plays</span>
                    </div>
                    <div className="flex gap-3">
                      <Button asChild>
                        <Link to={`/playlists/${playlist.id}`}>
                          <Play className="mr-2 h-4 w-4" />
                          Play Now
                        </Link>
                      </Button>
                      <Button variant="outline" className="bg-transparent">
                        <Heart className="mr-2 h-4 w-4" />
                        Save
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* All Playlists */}
        <TabsContent value="all" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {isLoading ? (
              // Loading skeletons
              Array(8)
                .fill(0)
                .map((_, index) => (
                  <Card
                    key={index}
                    className="overflow-hidden bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70"
                  >
                    <Skeleton className="h-48 w-full" />
                    <CardContent className="p-4">
                      <Skeleton className="h-6 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-1/2 mb-4" />
                      <Skeleton className="h-4 w-full mb-2" />
                      <Skeleton className="h-4 w-full" />
                    </CardContent>
                  </Card>
                ))
            ) : filteredPlaylists.length === 0 ? (
              <div className="col-span-full text-center py-10">
                <ListMusic className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-xl font-medium mb-2">No playlists found</h3>
                <p className="text-muted-foreground mb-6">Try adjusting your search or create a new playlist</p>
                <Button onClick={() => setSearchTerm("")}>Clear Search</Button>
              </div>
            ) : (
              filteredPlaylists.map((playlist) => (
                <Card
                  key={playlist.id}
                  className="overflow-hidden bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70 group"
                >
                  <div className="relative">
                    <img
                      src={playlist.image || "/placeholder.svg"}
                      alt={playlist.title}
                      className="h-48 w-full object-cover transition-transform group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Button size="icon" variant="secondary" className="rounded-full h-12 w-12">
                        <Play className="h-6 w-6 ml-1" />
                      </Button>
                    </div>
                    <div className="absolute top-3 right-3">
                      <Button variant="ghost" size="icon" className="h-8 w-8 bg-black/50 hover:bg-black/70">
                        <Heart className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="absolute bottom-3 left-3 flex items-center gap-2">
                      {playlist.isPublic ? (
                        <Badge variant="secondary" className="bg-green-600/80 text-white">
                          <Users className="h-3 w-3 mr-1" />
                          Public
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="bg-slate-600/80 text-white">
                          <Lock className="h-3 w-3 mr-1" />
                          Private
                        </Badge>
                      )}
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <Link to={`/playlists/${playlist.id}`}>
                      <h3 className="font-semibold text-lg mb-1 hover:text-primary transition-colors line-clamp-1">
                        {playlist.title}
                      </h3>
                    </Link>
                    <p className="text-sm text-muted-foreground mb-2">by {playlist.creator}</p>
                    <p className="text-sm line-clamp-2 mb-3">{playlist.description}</p>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <div className="flex items-center gap-3">
                        <span>{playlist.count} messages</span>
                        <span className="flex items-center gap-1">
                          <Heart className="h-3 w-3" />
                          {playlist.likes}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        <span>{new Date(playlist.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        {/* Popular Playlists */}
        <TabsContent value="popular" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {playlists
              .sort((a, b) => b.plays - a.plays)
              .map((playlist) => (
                <Card
                  key={playlist.id}
                  className="overflow-hidden bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70 group"
                >
                  <div className="relative">
                    <img
                      src={playlist.image || "/placeholder.svg"}
                      alt={playlist.title}
                      className="h-48 w-full object-cover transition-transform group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Button size="icon" variant="secondary" className="rounded-full h-12 w-12">
                        <Play className="h-6 w-6 ml-1" />
                      </Button>
                    </div>
                    <div className="absolute top-3 right-3">
                      <Button variant="ghost" size="icon" className="h-8 w-8 bg-black/50 hover:bg-black/70">
                        <Heart className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="absolute top-3 left-3">
                      <Badge className="bg-orange-600/80 text-white">
                        <Star className="h-3 w-3 mr-1" />
                        Popular
                      </Badge>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <Link to={`/playlists/${playlist.id}`}>
                      <h3 className="font-semibold text-lg mb-1 hover:text-primary transition-colors line-clamp-1">
                        {playlist.title}
                      </h3>
                    </Link>
                    <p className="text-sm text-muted-foreground mb-2">by {playlist.creator}</p>
                    <p className="text-sm line-clamp-2 mb-3">{playlist.description}</p>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <div className="flex items-center gap-3">
                        <span>{playlist.count} messages</span>
                        <span className="flex items-center gap-1">
                          <Heart className="h-3 w-3" />
                          {playlist.likes}
                        </span>
                      </div>
                      <span className="text-orange-400 font-medium">{playlist.plays} plays</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </TabsContent>

        {/* Recent Playlists */}
        <TabsContent value="recent" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {playlists
              .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
              .map((playlist) => (
                <Card
                  key={playlist.id}
                  className="overflow-hidden bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70 group"
                >
                  <div className="relative">
                    <img
                      src={playlist.image || "/placeholder.svg"}
                      alt={playlist.title}
                      className="h-48 w-full object-cover transition-transform group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Button size="icon" variant="secondary" className="rounded-full h-12 w-12">
                        <Play className="h-6 w-6 ml-1" />
                      </Button>
                    </div>
                    <div className="absolute top-3 right-3">
                      <Button variant="ghost" size="icon" className="h-8 w-8 bg-black/50 hover:bg-black/70">
                        <Heart className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="absolute top-3 left-3">
                      <Badge className="bg-blue-600/80 text-white">New</Badge>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <Link to={`/playlists/${playlist.id}`}>
                      <h3 className="font-semibold text-lg mb-1 hover:text-primary transition-colors line-clamp-1">
                        {playlist.title}
                      </h3>
                    </Link>
                    <p className="text-sm text-muted-foreground mb-2">by {playlist.creator}</p>
                    <p className="text-sm line-clamp-2 mb-3">{playlist.description}</p>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <div className="flex items-center gap-3">
                        <span>{playlist.count} messages</span>
                        <span className="flex items-center gap-1">
                          <Heart className="h-3 w-3" />
                          {playlist.likes}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        <span>{new Date(playlist.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
