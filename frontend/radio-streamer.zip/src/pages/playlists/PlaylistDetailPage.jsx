"use client"
import { useState, useRef, useEffect } from "react"
import { useParams, Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Play,
  Pause,
  ChevronLeft,
  Heart,
  Clock,
  Calendar,
  Share2,
  Download,
  MoreVertical,
  ListMusic,
  Loader2,
  Shuffle,
  Repeat,
} from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { toast } from "sonner"

export default function PlaylistDetailPage() {
  const { id } = useParams()
  const [isLoading, setIsLoading] = useState(false)
  const [isLiked, setIsLiked] = useState(false)
  const [currentTrackIndex, setCurrentTrackIndex] = useState(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const audioRef = useRef(null)
  const [isLoadingAudio, setIsLoadingAudio] = useState(false)

  // Sample playlist data
  const playlist = {
    id: 1,
    title: "Worship Anthems",
    description: "A collection of powerful worship songs to uplift your spirit and draw you closer to God.",
    image: "/images/house-exterior.jpg",
    creator: "Admin",
    createdAt: "2023-07-15",
    isPublic: true,
    likes: 234,
    plays: 1250,
    totalDuration: "2:45:30",
    messages: [
      {
        id: 1,
        title: "Amazing Grace",
        speaker: "Pastor Chris Oyakhilome",
        duration: "4:30",
        audioUrl: "https://example.com/audio1.mp3",
        image: "/images/house-exterior.jpg",
      },
      {
        id: 2,
        title: "How Great Thou Art",
        speaker: "Pastor Sarah Johnson",
        duration: "5:15",
        audioUrl: "https://example.com/audio2.mp3",
        image: "/images/house-exterior.jpg",
      },
      {
        id: 3,
        title: "Blessed Assurance",
        speaker: "Pastor Michael David",
        duration: "3:45",
        audioUrl: "https://example.com/audio3.mp3",
        image: "/images/house-exterior.jpg",
      },
      {
        id: 4,
        title: "Great Is Thy Faithfulness",
        speaker: "Pastor Grace Emmanuel",
        duration: "4:20",
        audioUrl: "https://example.com/audio4.mp3",
        image: "/images/house-exterior.jpg",
      },
      {
        id: 5,
        title: "It Is Well With My Soul",
        speaker: "Pastor Chris Oyakhilome",
        duration: "6:10",
        audioUrl: "https://example.com/audio5.mp3",
        image: "/images/house-exterior.jpg",
      },
    ],
    relatedPlaylists: [
      {
        id: 2,
        title: "Healing Declarations",
        creator: "Pastor Sarah",
        image: "/images/house-exterior.jpg",
        count: 10,
      },
      {
        id: 3,
        title: "Faith Builders",
        creator: "Pastor David",
        image: "/images/house-exterior.jpg",
        count: 15,
      },
    ],
  }

  // Audio control effects
  useEffect(() => {
    const audio = audioRef.current
    if (!audio || currentTrackIndex === null) return

    const handleCanPlay = () => setIsLoadingAudio(false)
    const handleWaiting = () => setIsLoadingAudio(true)
    const handleEnded = () => {
      setIsPlaying(false)
      // Auto play next track
      if (currentTrackIndex < playlist.messages.length - 1) {
        setCurrentTrackIndex(currentTrackIndex + 1)
        setIsPlaying(true)
      }
    }
    const handleError = (e) => {
      console.error("Audio error:", e)
      toast.error("Failed to load audio. Please try again.")
      setIsLoadingAudio(false)
      setIsPlaying(false)
    }

    audio.addEventListener("canplay", handleCanPlay)
    audio.addEventListener("waiting", handleWaiting)
    audio.addEventListener("ended", handleEnded)
    audio.addEventListener("error", handleError)

    return () => {
      audio.removeEventListener("canplay", handleCanPlay)
      audio.removeEventListener("waiting", handleWaiting)
      audio.removeEventListener("ended", handleEnded)
      audio.removeEventListener("error", handleError)
    }
  }, [currentTrackIndex, playlist.messages.length])

  useEffect(() => {
    const audio = audioRef.current
    if (!audio || currentTrackIndex === null) return

    if (isPlaying) {
      if (audio.paused) {
        setIsLoadingAudio(true)
        audio.play().catch((e) => {
          console.error("Error attempting to play audio:", e)
          toast.error("Playback failed. Please try clicking play again.")
          setIsLoadingAudio(false)
          setIsPlaying(false)
        })
      }
    } else {
      if (!audio.paused) {
        audio.pause()
      }
    }
  }, [isPlaying, currentTrackIndex])

  const togglePlayPause = (index) => {
    if (currentTrackIndex === index) {
      setIsPlaying(!isPlaying)
    } else {
      setCurrentTrackIndex(index)
      setIsPlaying(true)
    }
  }

  const playAll = () => {
    setCurrentTrackIndex(0)
    setIsPlaying(true)
  }

  const toggleLike = () => {
    setIsLiked(!isLiked)
    toast.success(isLiked ? "Removed from favorites" : "Added to favorites")
  }

  const handleShare = () => {
    if (navigator.share) {
      navigator
        .share({
          title: playlist.title,
          text: `Check out this playlist: ${playlist.title} by ${playlist.creator}`,
          url: window.location.href,
        })
        .catch((error) => console.log("Error sharing", error))
    } else {
      navigator.clipboard.writeText(window.location.href)
      toast.success("Link copied to clipboard!")
    }
  }

  const handleDownload = () => {
    toast.info("Downloading playlist...")
    // Implement download functionality
  }

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="w-full lg:w-2/3">
            <Skeleton className="h-8 w-48 mb-4" />
            <Skeleton className="h-64 w-full mb-6" />
            <Skeleton className="h-12 w-full mb-6" />
            <Skeleton className="h-6 w-3/4 mb-2" />
            <Skeleton className="h-6 w-1/2 mb-6" />
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-3/4" />
          </div>
          <div className="w-full lg:w-1/3">
            <Skeleton className="h-8 w-32 mb-4" />
            <Skeleton className="h-32 w-full mb-4" />
            <Skeleton className="h-32 w-full" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      {/* Audio Element */}
      {currentTrackIndex !== null && (
        <audio ref={audioRef} preload="auto" src={playlist.messages[currentTrackIndex].audioUrl}>
          Your browser does not support the audio element.
        </audio>
      )}

      {/* Back Button */}
      <Button variant="ghost" className="mb-6" asChild>
        <Link to="/playlists">
          <ChevronLeft className="mr-2 h-4 w-4" />
          Back to Playlists
        </Link>
      </Button>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Main Content */}
        <div className="w-full lg:w-2/3">
          {/* Playlist Header */}
          <Card className="bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70 mb-8">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="md:w-1/3">
                  <img
                    src={playlist.image || "/placeholder.svg"}
                    alt={playlist.title}
                    className="w-full aspect-square object-cover rounded-lg shadow-md"
                  />
                </div>
                <div className="md:w-2/3">
                  <div className="flex items-center mb-2">
                    <ListMusic className="h-5 w-5 text-primary mr-2" />
                    <h1 className="text-3xl font-bold">{playlist.title}</h1>
                  </div>
                  <div className="flex items-center mb-3 text-muted-foreground">
                    <span className="mr-4">Created by {playlist.creator}</span>
                    <span className="mr-4">{playlist.messages.length} messages</span>
                    <span>{playlist.totalDuration}</span>
                  </div>
                  <p className="mb-6">{playlist.description}</p>
                  <div className="flex items-center text-sm text-muted-foreground mb-6">
                    <Calendar className="h-4 w-4 mr-1" />
                    <span className="mr-4">{new Date(playlist.createdAt).toLocaleDateString()}</span>
                    <Heart className="h-4 w-4 mr-1" />
                    <span className="mr-4">{playlist.likes} likes</span>
                    <span>{playlist.plays} plays</span>
                  </div>
                  <div className="flex flex-wrap gap-3">
                    <Button onClick={playAll} className="bg-primary hover:bg-primary/90">
                      <Play className="mr-2 h-4 w-4" />
                      Play All
                    </Button>
                    <Button variant="outline" onClick={toggleLike} className="bg-transparent">
                      <Heart className={`mr-2 h-4 w-4 ${isLiked ? "fill-red-500 text-red-500" : ""}`} />
                      {isLiked ? "Liked" : "Like"}
                    </Button>
                    <Button variant="outline" onClick={handleShare} className="bg-transparent">
                      <Share2 className="mr-2 h-4 w-4" />
                      Share
                    </Button>
                    <Button variant="outline" onClick={handleDownload} className="bg-transparent">
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Playlist Controls */}
          <Card className="bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70 mb-8">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Button variant="ghost" size="icon">
                    <Shuffle className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Repeat className="h-5 w-5" />
                  </Button>
                </div>
                <div className="text-sm text-muted-foreground">
                  {playlist.messages.length} messages • {playlist.totalDuration}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Messages List */}
          <Card className="bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70">
            <CardContent className="p-6">
              <div className="space-y-4">
                {playlist.messages.map((message, index) => (
                  <div
                    key={message.id}
                    className={`flex items-center gap-4 p-4 rounded-lg transition-colors ${
                      currentTrackIndex === index && isPlaying
                        ? "bg-primary/10 border border-primary/20"
                        : "hover:bg-muted/50"
                    }`}
                  >
                    <div className="flex items-center gap-4 flex-1">
                      <Button
                        size="icon"
                        className="h-10 w-10 rounded-full flex-shrink-0"
                        onClick={() => togglePlayPause(index)}
                      >
                        {isLoadingAudio && currentTrackIndex === index && isPlaying ? (
                          <Loader2 className="h-5 w-5 animate-spin" />
                        ) : currentTrackIndex === index && isPlaying ? (
                          <Pause className="h-5 w-5" />
                        ) : (
                          <Play className="h-5 w-5 ml-1" />
                        )}
                      </Button>
                      <img
                        src={message.image || "/placeholder.svg"}
                        alt={message.title}
                        className="w-12 h-12 rounded-md object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium truncate">{message.title}</h3>
                        <p className="text-sm text-muted-foreground truncate">{message.speaker}</p>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <Clock className="h-4 w-4" />
                        <span>{message.duration}</span>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem>
                          <Heart className="mr-2 h-4 w-4" />
                          Add to Favorites
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <ListMusic className="mr-2 h-4 w-4" />
                          Add to Playlist
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Share2 className="mr-2 h-4 w-4" />
                          Share
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Download className="mr-2 h-4 w-4" />
                          Download
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="w-full lg:w-1/3">
          {/* Related Playlists */}
          <Card className="bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70 mb-6">
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Related Playlists</h2>
              <div className="space-y-4">
                {playlist.relatedPlaylists.map((related) => (
                  <Link key={related.id} to={`/playlists/${related.id}`}>
                    <div className="flex gap-3 group">
                      <img
                        src={related.image || "/placeholder.svg"}
                        alt={related.title}
                        className="h-16 w-16 object-cover rounded-md"
                      />
                      <div>
                        <h3 className="font-medium text-sm group-hover:text-primary transition-colors">
                          {related.title}
                        </h3>
                        <p className="text-xs text-muted-foreground">by {related.creator}</p>
                        <p className="text-xs text-muted-foreground">{related.count} messages</p>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Playlist Stats */}
          <Card className="bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70">
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Playlist Stats</h2>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Total Messages</span>
                  <span className="font-medium">{playlist.messages.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Total Duration</span>
                  <span className="font-medium">{playlist.totalDuration}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Likes</span>
                  <span className="font-medium">{playlist.likes}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Plays</span>
                  <span className="font-medium">{playlist.plays}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Created</span>
                  <span className="font-medium">{new Date(playlist.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
