"use client"
import { useState, useEffect } from "react"
import { useSearchParams } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Skeleton } from "@/components/ui/skeleton"
import { Search, Play, Clock, Mic, BookOpen, Users, X } from "lucide-react"
import { Link } from "react-router-dom"

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const [searchQuery, setSearchQuery] = useState(searchParams.get("q") || "")
  const [isLoading, setIsLoading] = useState(false)
  const [results, setResults] = useState({
    messages: [],
    podcasts: [],
    playlists: [],
  })
  const [recentSearches, setRecentSearches] = useState([])

  // Load recent searches from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("recentSearches")
    if (saved) {
      setRecentSearches(JSON.parse(saved))
    }
  }, [])

  // Perform search when query changes
  useEffect(() => {
    if (searchQuery.trim()) {
      performSearch(searchQuery)
    } else {
      setResults({ messages: [], podcasts: [], playlists: [] })
    }
  }, [searchQuery])

  const performSearch = async (query) => {
    setIsLoading(true)
    try {
      // Simulate API calls - replace with actual API calls
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Mock results
      const mockResults = {
        messages: [
          {
            id: 1,
            title: "The Power of Faith in Difficult Times",
            speaker: "Pastor Chris Oyakhilome",
            duration: "45:30",
            image_url: "/placeholder.svg?height=120&width=200",
            category: { name: "Faith" },
            listens: 1250,
            is_favorited: false,
          },
          {
            id: 2,
            title: "Walking in Divine Health",
            speaker: "Pastor Chris Oyakhilome",
            duration: "38:15",
            image_url: "/placeholder.svg?height=120&width=200",
            category: { name: "Healing" },
            listens: 980,
            is_favorited: true,
          },
        ],
        podcasts: [
          {
            id: 1,
            title: "Faith Foundations",
            host: "Pastor Sarah",
            episodes_count: 15,
            image_url: "/placeholder.svg?height=120&width=120",
            category: { name: "Faith" },
            rating: 4.8,
            is_subscribed: false,
          },
        ],
        playlists: [
          {
            id: 1,
            title: "Worship Anthems",
            description: "A collection of powerful worship songs",
            count: 15,
            image_url: "/placeholder.svg?height=120&width=200",
          },
        ],
      }

      setResults(mockResults)

      // Save to recent searches
      const newRecentSearches = [query, ...recentSearches.filter((s) => s !== query)].slice(0, 5)
      setRecentSearches(newRecentSearches)
      localStorage.setItem("recentSearches", JSON.stringify(newRecentSearches))
    } catch (error) {
      console.error("Search failed:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSearch = (e) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      setSearchParams({ q: searchQuery })
      performSearch(searchQuery)
    }
  }

  const clearSearch = () => {
    setSearchQuery("")
    setSearchParams({})
    setResults({ messages: [], podcasts: [], playlists: [] })
  }

  const removeRecentSearch = (searchToRemove) => {
    const updated = recentSearches.filter((s) => s !== searchToRemove)
    setRecentSearches(updated)
    localStorage.setItem("recentSearches", JSON.stringify(updated))
  }

  const totalResults = results.messages.length + results.podcasts.length + results.playlists.length

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Search Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">Search</h1>

        {/* Search Form */}
        <form onSubmit={handleSearch} className="relative max-w-2xl">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            placeholder="Search messages, podcasts, playlists..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-12 pr-12 h-12 text-lg"
          />
          {searchQuery && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={clearSearch}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </form>
      </div>

      {/* Recent Searches */}
      {!searchQuery && recentSearches.length > 0 && (
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-4">Recent Searches</h2>
          <div className="flex flex-wrap gap-2">
            {recentSearches.map((search, index) => (
              <div key={index} className="flex items-center gap-1 bg-muted rounded-full px-3 py-1">
                <button onClick={() => setSearchQuery(search)} className="text-sm hover:text-primary">
                  {search}
                </button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeRecentSearch(search)}
                  className="h-4 w-4 p-0 hover:bg-transparent"
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Search Results */}
      {searchQuery && (
        <div className="space-y-6">
          {/* Results Summary */}
          <div className="flex items-center justify-between">
            <p className="text-muted-foreground">
              {isLoading ? "Searching..." : `${totalResults} results for "${searchQuery}"`}
            </p>
          </div>

          {isLoading ? (
            <div className="space-y-6">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="space-y-4">
                  <Skeleton className="h-6 w-32" />
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {Array.from({ length: 3 }).map((_, j) => (
                      <Card key={j}>
                        <Skeleton className="h-32 w-full" />
                        <CardContent className="p-4">
                          <Skeleton className="h-4 w-3/4 mb-2" />
                          <Skeleton className="h-3 w-1/2" />
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : totalResults > 0 ? (
            <Tabs defaultValue="all" className="space-y-6">
              <TabsList>
                <TabsTrigger value="all">All ({totalResults})</TabsTrigger>
                <TabsTrigger value="messages">Messages ({results.messages.length})</TabsTrigger>
                <TabsTrigger value="podcasts">Podcasts ({results.podcasts.length})</TabsTrigger>
                <TabsTrigger value="playlists">Playlists ({results.playlists.length})</TabsTrigger>
              </TabsList>

              <TabsContent value="all" className="space-y-8">
                {/* Messages Section */}
                {results.messages.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <BookOpen className="h-5 w-5" />
                      <h2 className="text-xl font-semibold">Messages</h2>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {results.messages.map((message) => (
                        <Card
                          key={message.id}
                          className="group overflow-hidden hover:shadow-lg transition-all duration-300"
                        >
                          <div className="relative">
                            <img
                              src={message.image_url || "/placeholder.svg"}
                              alt={message.title}
                              className="w-full h-32 object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                              <Button size="sm" className="bg-white/20 backdrop-blur-sm hover:bg-white/30">
                                <Play className="h-4 w-4 mr-2" />
                                Play
                              </Button>
                            </div>
                          </div>
                          <CardContent className="p-4">
                            <Link to={`/messages/${message.id}`}>
                              <h3 className="font-semibold line-clamp-2 group-hover:text-primary transition-colors">
                                {message.title}
                              </h3>
                            </Link>
                            <p className="text-sm text-muted-foreground mt-1">{message.speaker}</p>
                            <div className="flex items-center justify-between mt-3">
                              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                <Clock className="h-3 w-3" />
                                {message.duration}
                              </div>
                              <Badge variant="secondary" className="text-xs">
                                {message.category.name}
                              </Badge>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* Podcasts Section */}
                {results.podcasts.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <Mic className="h-5 w-5" />
                      <h2 className="text-xl font-semibold">Podcasts</h2>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {results.podcasts.map((podcast) => (
                        <Card
                          key={podcast.id}
                          className="group overflow-hidden hover:shadow-lg transition-all duration-300"
                        >
                          <div className="relative">
                            <img
                              src={podcast.image_url || "/placeholder.svg"}
                              alt={podcast.title}
                              className="w-full h-32 object-cover"
                            />
                            <div className="absolute top-2 left-2">
                              <Badge className="bg-black/20 backdrop-blur-sm text-white border-white/30">
                                <Mic className="h-3 w-3 mr-1" />
                                Podcast
                              </Badge>
                            </div>
                          </div>
                          <CardContent className="p-4">
                            <Link to={`/podcasts/${podcast.id}`}>
                              <h3 className="font-semibold line-clamp-2 group-hover:text-primary transition-colors">
                                {podcast.title}
                              </h3>
                            </Link>
                            <p className="text-sm text-muted-foreground mt-1">{podcast.host}</p>
                            <div className="flex items-center justify-between mt-3">
                              <span className="text-xs text-muted-foreground">{podcast.episodes_count} episodes</span>
                              <Badge variant="secondary" className="text-xs">
                                {podcast.category.name}
                              </Badge>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* Playlists Section */}
                {results.playlists.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <Users className="h-5 w-5" />
                      <h2 className="text-xl font-semibold">Playlists</h2>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {results.playlists.map((playlist) => (
                        <Card
                          key={playlist.id}
                          className="group overflow-hidden hover:shadow-lg transition-all duration-300"
                        >
                          <div className="relative">
                            <img
                              src={playlist.image_url || "/placeholder.svg"}
                              alt={playlist.title}
                              className="w-full h-32 object-cover"
                            />
                          </div>
                          <CardContent className="p-4">
                            <Link to={`/playlists/${playlist.id}`}>
                              <h3 className="font-semibold line-clamp-2 group-hover:text-primary transition-colors">
                                {playlist.title}
                              </h3>
                            </Link>
                            <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{playlist.description}</p>
                            <div className="flex items-center justify-between mt-3">
                              <span className="text-xs text-muted-foreground">{playlist.count} items</span>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="messages">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {results.messages.map((message) => (
                    <Card
                      key={message.id}
                      className="group overflow-hidden hover:shadow-lg transition-all duration-300"
                    >
                      <div className="relative">
                        <img
                          src={message.image_url || "/placeholder.svg"}
                          alt={message.title}
                          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                          <Button size="sm" className="bg-white/20 backdrop-blur-sm hover:bg-white/30">
                            <Play className="h-4 w-4 mr-2" />
                            Play
                          </Button>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <Link to={`/messages/${message.id}`}>
                          <h3 className="font-semibold line-clamp-2 group-hover:text-primary transition-colors">
                            {message.title}
                          </h3>
                        </Link>
                        <p className="text-sm text-muted-foreground mt-1">{message.speaker}</p>
                        <div className="flex items-center justify-between mt-3">
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            {message.duration}
                          </div>
                          <Badge variant="secondary" className="text-xs">
                            {message.category.name}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="podcasts">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {results.podcasts.map((podcast) => (
                    <Card
                      key={podcast.id}
                      className="group overflow-hidden hover:shadow-lg transition-all duration-300"
                    >
                      <div className="relative">
                        <img
                          src={podcast.image_url || "/placeholder.svg"}
                          alt={podcast.title}
                          className="w-full h-48 object-cover"
                        />
                        <div className="absolute top-2 left-2">
                          <Badge className="bg-black/20 backdrop-blur-sm text-white border-white/30">
                            <Mic className="h-3 w-3 mr-1" />
                            Podcast
                          </Badge>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <Link to={`/podcasts/${podcast.id}`}>
                          <h3 className="font-semibold line-clamp-2 group-hover:text-primary transition-colors">
                            {podcast.title}
                          </h3>
                        </Link>
                        <p className="text-sm text-muted-foreground mt-1">{podcast.host}</p>
                        <div className="flex items-center justify-between mt-3">
                          <span className="text-xs text-muted-foreground">{podcast.episodes_count} episodes</span>
                          <Badge variant="secondary" className="text-xs">
                            {podcast.category.name}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="playlists">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {results.playlists.map((playlist) => (
                    <Card
                      key={playlist.id}
                      className="group overflow-hidden hover:shadow-lg transition-all duration-300"
                    >
                      <div className="relative">
                        <img
                          src={playlist.image_url || "/placeholder.svg"}
                          alt={playlist.title}
                          className="w-full h-48 object-cover"
                        />
                      </div>
                      <CardContent className="p-4">
                        <Link to={`/playlists/${playlist.id}`}>
                          <h3 className="font-semibold line-clamp-2 group-hover:text-primary transition-colors">
                            {playlist.title}
                          </h3>
                        </Link>
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{playlist.description}</p>
                        <div className="flex items-center justify-between mt-3">
                          <span className="text-xs text-muted-foreground">{playlist.count} items</span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          ) : (
            <div className="text-center py-12">
              <Search className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-50" />
              <h3 className="text-lg font-semibold mb-2">No results found</h3>
              <p className="text-muted-foreground mb-4">Try adjusting your search terms or browse our categories</p>
              <div className="flex gap-2 justify-center">
                <Link to="/messages">
                  <Button variant="outline">Browse Messages</Button>
                </Link>
                <Link to="/podcasts">
                  <Button variant="outline">Browse Podcasts</Button>
                </Link>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Popular Searches */}
      {!searchQuery && (
        <div className="mt-12">
          <h2 className="text-lg font-semibold mb-4">Popular Searches</h2>
          <div className="flex flex-wrap gap-2">
            {["faith", "healing", "prosperity", "prayer", "salvation", "worship"].map((term) => (
              <Button
                key={term}
                variant="outline"
                size="sm"
                onClick={() => setSearchQuery(term)}
                className="capitalize"
              >
                {term}
              </Button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
