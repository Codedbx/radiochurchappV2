"use client"
import { useState } from "react"
import { Link } from "react-router-dom"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Heart, Volume2, MessageCircle, Copy, Home, ArrowRight, Play, Clock } from "lucide-react"

export default function CategoriesPage() {
  const [isLoading] = useState(false)

  // Mock data - replace with actual API calls
  const categories = [
    {
      id: 1,
      name: "Faith",
      description: "Messages about building and strengthening your faith",
      icon: <Heart className="h-8 w-8" />,
      color: "from-red-500 to-pink-500",
      count: 45,
      image_url: "/placeholder.svg?height=200&width=300",
      featured_messages: [
        { id: 1, title: "The Power of Faith", speaker: "Pastor Chris", duration: "45:30" },
        { id: 2, title: "Faith That Moves Mountains", speaker: "Pastor Sarah", duration: "38:15" },
      ],
    },
    {
      id: 2,
      name: "Healing",
      description: "Divine health and healing messages",
      icon: <Volume2 className="h-8 w-8" />,
      color: "from-green-500 to-emerald-500",
      count: 32,
      image_url: "/placeholder.svg?height=200&width=300",
      featured_messages: [
        { id: 3, title: "Walking in Divine Health", speaker: "Pastor Chris", duration: "42:20" },
        { id: 4, title: "Healing Scriptures", speaker: "Pastor Michael", duration: "35:45" },
      ],
    },
    {
      id: 3,
      name: "Prayer",
      description: "Learn the power and principles of effective prayer",
      icon: <MessageCircle className="h-8 w-8" />,
      color: "from-blue-500 to-cyan-500",
      count: 28,
      image_url: "/placeholder.svg?height=200&width=300",
      featured_messages: [
        { id: 5, title: "The Prayer of Faith", speaker: "Pastor Grace", duration: "40:10" },
        { id: 6, title: "Praying in the Spirit", speaker: "Pastor David", duration: "33:25" },
      ],
    },
    {
      id: 4,
      name: "Prosperity",
      description: "Biblical principles of financial abundance",
      icon: <Copy className="h-8 w-8" />,
      color: "from-yellow-500 to-orange-500",
      count: 38,
      image_url: "/placeholder.svg?height=200&width=300",
      featured_messages: [
        { id: 7, title: "God's Will for Your Prosperity", speaker: "Pastor Chris", duration: "48:30" },
        { id: 8, title: "The Blessing of Abraham", speaker: "Pastor John", duration: "41:15" },
      ],
    },
    {
      id: 5,
      name: "Salvation",
      description: "Understanding your salvation and new life in Christ",
      icon: <Home className="h-8 w-8" />,
      color: "from-purple-500 to-violet-500",
      count: 25,
      image_url: "/placeholder.svg?height=200&width=300",
      featured_messages: [
        { id: 9, title: "Born Again Experience", speaker: "Pastor Chris", duration: "44:20" },
        { id: 10, title: "Your New Identity", speaker: "Pastor Mary", duration: "36:50" },
      ],
    },
    {
      id: 6,
      name: "Worship",
      description: "Messages about true worship and praise",
      icon: <Heart className="h-8 w-8" />,
      color: "from-indigo-500 to-purple-500",
      count: 22,
      image_url: "/placeholder.svg?height=200&width=300",
      featured_messages: [
        { id: 11, title: "Worship in Spirit and Truth", speaker: "Pastor Paul", duration: "39:40" },
        { id: 12, title: "The Heart of Worship", speaker: "Pastor Ruth", duration: "37:25" },
      ],
    },
  ]

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <Skeleton className="h-8 w-64 mb-2" />
        <Skeleton className="h-4 w-96 mb-8" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i}>
              <Skeleton className="h-48 w-full" />
              <CardContent className="p-6">
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-full mb-4" />
                <Skeleton className="h-4 w-1/2" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Message Categories</h1>
        <p className="text-muted-foreground">
          Explore messages organized by topics to help you grow in specific areas of faith
        </p>
      </div>

      {/* Categories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
        {categories.map((category) => (
          <Card key={category.id} className="group overflow-hidden hover:shadow-xl transition-all duration-300">
            <div className="relative">
              {/* Category Header with Gradient */}
              <div className={`h-32 bg-gradient-to-br ${category.color} relative overflow-hidden`}>
                <div className="absolute inset-0 bg-black/20" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-white">{category.icon}</div>
                </div>
                <div className="absolute top-4 right-4">
                  <Badge className="bg-white/20 backdrop-blur-sm text-white border-white/30">
                    {category.count} messages
                  </Badge>
                </div>
              </div>
            </div>

            <CardContent className="p-6">
              <div className="mb-4">
                <h3 className="text-xl font-semibold mb-2 group-hover:text-primary transition-colors">
                  {category.name}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{category.description}</p>
              </div>

              {/* Featured Messages */}
              <div className="space-y-3 mb-4">
                <h4 className="font-medium text-sm text-muted-foreground">Featured Messages:</h4>
                {category.featured_messages.map((message) => (
                  <div
                    key={message.id}
                    className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <Play className="h-3 w-3 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm line-clamp-1">{message.title}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>{message.speaker}</span>
                        <span>•</span>
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {message.duration}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <Link to={`/messages?category=${category.name.toLowerCase()}`}>
                <Button className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  View All {category.name} Messages
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Popular Categories Section */}
      <div className="bg-muted/30 rounded-xl p-8">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold mb-2">Most Popular Categories</h2>
          <p className="text-muted-foreground">These categories have the most listened-to messages</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {categories
            .sort((a, b) => b.count - a.count)
            .slice(0, 3)
            .map((category, index) => (
              <Card key={category.id} className="text-center hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="relative mb-4">
                    <div
                      className={`w-16 h-16 mx-auto rounded-full bg-gradient-to-br ${category.color} flex items-center justify-center text-white mb-2`}
                    >
                      {category.icon}
                    </div>
                    <div className="absolute -top-2 -right-2 w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white text-sm font-bold">
                      #{index + 1}
                    </div>
                  </div>
                  <h3 className="font-semibold text-lg mb-2">{category.name}</h3>
                  <p className="text-muted-foreground text-sm mb-4">{category.count} messages</p>
                  <Link to={`/messages?category=${category.name.toLowerCase()}`}>
                    <Button variant="outline" size="sm">
                      Explore
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
        </div>
      </div>

      {/* Browse All Section */}
      <div className="mt-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Can't find what you're looking for?</h2>
        <p className="text-muted-foreground mb-6">
          Browse all our messages or use the search function to find specific topics
        </p>
        <div className="flex gap-4 justify-center">
          <Link to="/messages">
            <Button size="lg">Browse All Messages</Button>
          </Link>
          <Link to="/search">
            <Button variant="outline" size="lg">
              Search Messages
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
