"use client"
import { useState } from "react"
import { Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  BookOpen,
  Mic,
  ListMusic,
  Heart,
  Plus,
  Search,
  MoreVertical,
  Play,
  Clock,
  Grid3X3,
  List,
  SortAsc,
  Edit,
  Trash2,
  Share2,
  Download,
  Eye,
  EyeOff,
  ChevronDown,
} from "lucide-react"
import { useFavorites, useToggleFavorite } from "../hooks/useFavorites"
import { useUserPlaylists, useCreatePlaylist, useDeletePlaylist } from "../hooks/usePlaylists"
import { toast } from "sonner"

export default function LibraryPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [viewMode, setViewMode] = useState("grid") // grid or list
  const [sortBy, setSortBy] = useState("recent")
  const [activeFilter, setActiveFilter] = useState("all")
  const [isCreatePlaylistOpen, setIsCreatePlaylistOpen] = useState(false)
  const [newPlaylistName, setNewPlaylistName] = useState("")
  const [newPlaylistDescription, setNewPlaylistDescription] = useState("")
  const [isCreatingPlaylist, setIsCreatingPlaylist] = useState(false)

  // Fetch user's data
  const { data: favorites, isLoading: favoritesLoading } = useFavorites()
  const { data: userPlaylists, isLoading: playlistsLoading } = useUserPlaylists()
  const toggleFavorite = useToggleFavorite()
  const createPlaylist = useCreatePlaylist()
  const deletePlaylist = useDeletePlaylist()

  // Sample data for demonstration
  const sampleFavorites = {
    messages: [
      {
        id: 1,
        title: "The Power of Your Mind",
        speaker: "Pastor Chris Oyakhilome",
        duration: "1:15:30",
        image: "/placeholder.svg?height=300&width=200&text=The+Power+of+Your+Mind",
        addedAt: "2023-08-15",
      },
      {
        id: 2,
        title: "Healing Streams of God",
        speaker: "Pastor Chris Oyakhilome",
        duration: "0:58:10",
        image: "/placeholder.svg?height=300&width=200&text=Healing+Streams",
        addedAt: "2023-08-10",
      },
      {
        id: 3,
        title: "Faith That Moves Mountains",
        speaker: "Pastor Chris Oyakhilome",
        duration: "0:42:15",
        image: "/placeholder.svg?height=300&width=200&text=Faith+Mountains",
        addedAt: "2023-08-05",
      },
      {
        id: 4,
        title: "The Holy Spirit and You",
        speaker: "Pastor Chris Oyakhilome",
        duration: "1:05:00",
        image: "/placeholder.svg?height=300&width=200&text=Holy+Spirit",
        addedAt: "2023-08-01",
      },
      {
        id: 5,
        title: "Prosperity Consciousness",
        speaker: "Pastor Sarah Johnson",
        duration: "1:05:00",
        image: "/placeholder.svg?height=300&width=200&text=Prosperity",
        addedAt: "2023-07-28",
      },
      {
        id: 6,
        title: "Effective Prayer Strategies",
        speaker: "Pastor Chris Oyakhilome",
        duration: "0:45:30",
        image: "/placeholder.svg?height=300&width=200&text=Prayer+Strategies",
        addedAt: "2023-07-25",
      },
    ],
    podcasts: [
      {
        id: 1,
        title: "Faith Foundations",
        host: "Pastor Sarah",
        episodes: 24,
        image: "/placeholder.svg?height=200&width=200&text=Faith+Foundations",
        addedAt: "2023-08-12",
      },
      {
        id: 2,
        title: "Spiritual Growth",
        host: "Pastor Michael",
        episodes: 18,
        image: "/placeholder.svg?height=200&width=200&text=Spiritual+Growth",
        addedAt: "2023-08-08",
      },
    ],
  }

  const sampleUserPlaylists = [
    {
      id: 1,
      title: "Saved",
      description: "Collection of my most loved messages",
      count: 3,
      images: [
        "/placeholder.svg?height=200&width=200&text=Boy+Swallows+Universe",
        "/placeholder.svg?height=200&width=200&text=Message+2",
        "/placeholder.svg?height=200&width=200&text=Message+3",
      ],
      isPublic: true,
      createdAt: "2023-07-15",
      type: "saved",
    },
    {
      id: 2,
      title: "Seen/Rated",
      description: "Messages I've watched and rated",
      count: 0,
      images: [],
      isPublic: false,
      createdAt: "2023-07-20",
      type: "rated",
    },
    {
      id: 3,
      title: "Untitled list",
      description: "Custom playlist",
      count: 3,
      images: [
        "/placeholder.svg?height=200&width=200&text=The+Penguin",
        "/placeholder.svg?height=200&width=200&text=Essential+Killing",
        "/placeholder.svg?height=200&width=200&text=Tar",
      ],
      isPublic: true,
      createdAt: "2023-07-25",
      type: "custom",
    },
    {
      id: 4,
      title: "Tracked titles",
      description: "Messages I'm tracking",
      count: 1,
      images: ["/placeholder.svg?height=200&width=200&text=Boy+Swallows+Universe"],
      isPublic: false,
      createdAt: "2023-08-01",
      type: "tracked",
    },
  ]

  // Use sample data if API data is not available
  const favoritesData = favorites?.data || sampleFavorites
  const playlistsData = userPlaylists?.data || sampleUserPlaylists

  const handleCreatePlaylist = async () => {
    if (!newPlaylistName.trim()) return

    setIsCreatingPlaylist(true)
    try {
      await createPlaylist.mutateAsync({
        title: newPlaylistName,
        description: newPlaylistDescription,
        isPublic: false,
      })

      setNewPlaylistName("")
      setNewPlaylistDescription("")
      setIsCreatePlaylistOpen(false)
      toast.success("Playlist created successfully!")
    } catch (error) {
      toast.error("Failed to create playlist")
    } finally {
      setIsCreatingPlaylist(false)
    }
  }

  const handleDeletePlaylist = async (playlistId, playlistTitle) => {
    if (window.confirm(`Are you sure you want to delete "${playlistTitle}"?`)) {
      try {
        await deletePlaylist.mutateAsync(playlistId)
        toast.success("Playlist deleted successfully!")
      } catch (error) {
        toast.error("Failed to delete playlist")
      }
    }
  }

  const handleToggleFavorite = async (type, id) => {
    try {
      await toggleFavorite.mutateAsync({ type, id, isFavorited: true })
      toast.success("Removed from favorites")
    } catch (error) {
      toast.error("Failed to update favorites")
    }
  }

  const filteredPlaylists = playlistsData.filter((playlist) => {
    if (activeFilter === "all") return true
    if (activeFilter === "by-you") return playlist.type === "custom"
    if (activeFilter === "seen-rated") return playlist.type === "rated"
    if (activeFilter === "subscribed") return playlist.type === "subscribed"
    return true
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50/30 dark:from-slate-900 dark:via-slate-800 dark:to-violet-900/20">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div>
              <h1 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">My Library</h1>
              <p className="text-slate-600 dark:text-slate-400">Your personal collection of spiritual content</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500 dark:text-slate-400" />
                <Input
                  type="search"
                  placeholder="Search your library..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 bg-white/70 dark:bg-slate-800/70 border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white placeholder:text-slate-500 dark:placeholder:text-slate-400 backdrop-blur-sm"
                />
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="outline"
                    size="icon"
                    className="bg-white/70 dark:bg-slate-800/70 border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white backdrop-blur-sm hover:bg-white/90 dark:hover:bg-slate-700/90"
                  >
                    <SortAsc className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-white/95 dark:bg-slate-800/95 border-slate-200 dark:border-slate-700 backdrop-blur-sm">
                  <DropdownMenuItem
                    onClick={() => setSortBy("recent")}
                    className="text-slate-900 dark:text-white hover:bg-slate-100 dark:hover:bg-slate-700"
                  >
                    Recently Added
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => setSortBy("alphabetical")}
                    className="text-slate-900 dark:text-white hover:bg-slate-100 dark:hover:bg-slate-700"
                  >
                    Alphabetical
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => setSortBy("duration")}
                    className="text-slate-900 dark:text-white hover:bg-slate-100 dark:hover:bg-slate-700"
                  >
                    Duration
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <div className="flex items-center bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm rounded-lg p-1 border border-slate-300 dark:border-slate-600">
                <Button
                  variant={viewMode === "grid" ? "default" : "ghost"}
                  size="icon"
                  onClick={() => setViewMode("grid")}
                  className="h-8 w-8"
                >
                  <Grid3X3 className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "ghost"}
                  size="icon"
                  onClick={() => setViewMode("list")}
                  className="h-8 w-8"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Top Picks Section */}
          <div className="mb-8">
            <div className="bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm rounded-xl p-6 border border-slate-200 dark:border-slate-700">
              <h2 className="text-xl font-semibold text-slate-900 dark:text-white mb-4">Top picks for you</h2>
              <p className="text-slate-600 dark:text-slate-400 mb-6">
                Messages, shows and podcasts curated just for you
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {favoritesData.messages?.slice(0, 6).map((message) => (
                  <div key={message.id} className="group cursor-pointer">
                    <div className="relative h-32 rounded-lg overflow-hidden mb-2 border border-slate-200 dark:border-slate-700">
                      <img
                        src={"/images/house-exterior.jpg"}
                        alt={message.title}
                        className="w-full h-full object-cover transition-transform group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Button
                          size="icon"
                          variant="secondary"
                          className="rounded-full h-12 w-12 bg-white/90 dark:bg-slate-800/90 text-slate-900 dark:text-white"
                        >
                          <Play className="h-6 w-6 ml-1" />
                        </Button>
                      </div>
                    </div>
                    <h3 className="text-sm font-medium text-slate-900 dark:text-white line-clamp-2">{message.title}</h3>
                    <p className="text-xs text-slate-600 dark:text-slate-400">{message.speaker}</p>
                  </div>
                ))}
              </div>
              <Button
                variant="ghost"
                className="mt-4 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
              >
                View all →
              </Button>
            </div>
          </div>
        </div>

        <Tabs defaultValue="favorites" className="w-full">
          <TabsList className="bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm border border-slate-200 dark:border-slate-700 mb-8">
            <TabsTrigger
              value="favorites"
              className="data-[state=active]:bg-slate-100 dark:data-[state=active]:bg-slate-700 text-slate-900 dark:text-white"
            >
              <Heart className="mr-2 h-4 w-4" />
              Favorites
            </TabsTrigger>
            <TabsTrigger
              value="playlists"
              className="data-[state=active]:bg-slate-100 dark:data-[state=active]:bg-slate-700 text-slate-900 dark:text-white"
            >
              <ListMusic className="mr-2 h-4 w-4" />
              My Playlists
            </TabsTrigger>
            <TabsTrigger
              value="history"
              className="data-[state=active]:bg-slate-100 dark:data-[state=active]:bg-slate-700 text-slate-900 dark:text-white"
            >
              <Clock className="mr-2 h-4 w-4" />
              Recently Played
            </TabsTrigger>
          </TabsList>

          {/* Favorites Tab */}
          <TabsContent value="favorites" className="mt-0">
            <Tabs defaultValue="all" className="w-full">
              <TabsList className="bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm border border-slate-200 dark:border-slate-700 mb-6">
                <TabsTrigger
                  value="all"
                  className="data-[state=active]:bg-slate-100 dark:data-[state=active]:bg-slate-700 text-slate-900 dark:text-white"
                >
                  All
                </TabsTrigger>
                <TabsTrigger
                  value="messages"
                  className="data-[state=active]:bg-slate-100 dark:data-[state=active]:bg-slate-700 text-slate-900 dark:text-white"
                >
                  <BookOpen className="mr-2 h-4 w-4" />
                  Messages
                </TabsTrigger>
                <TabsTrigger
                  value="podcasts"
                  className="data-[state=active]:bg-slate-100 dark:data-[state=active]:bg-slate-700 text-slate-900 dark:text-white"
                >
                  <Mic className="mr-2 h-4 w-4" />
                  Podcasts
                </TabsTrigger>
              </TabsList>

              {/* All Favorites */}
              <TabsContent value="all" className="mt-0">
                <div
                  className={
                    viewMode === "grid"
                      ? "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4"
                      : "space-y-3"
                  }
                >
                  {/* Messages */}
                  {favoritesData.messages?.map((message) => (
                    <div
                      key={`message-${message.id}`}
                      className={
                        viewMode === "grid"
                          ? "group"
                          : "flex items-center gap-4 p-3 bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm rounded-lg border border-slate-200 dark:border-slate-700"
                      }
                    >
                      {viewMode === "grid" ? (
                        <>
                          <div className="relative aspect-[3/4] rounded-lg overflow-hidden mb-3 border border-slate-200 dark:border-slate-700">
                            <img
                              src={"/images/house-exterior.jpg"}
                              alt={message.title}
                              className="w-full h-full object-cover transition-transform group-hover:scale-105"
                            />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                              <Button
                                size="icon"
                                variant="secondary"
                                className="rounded-full h-10 w-10 bg-white/90 dark:bg-slate-800/90 text-slate-900 dark:text-white"
                              >
                                <Play className="h-5 w-5 ml-1" />
                              </Button>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="absolute top-2 right-2 h-8 w-8 bg-black/50 hover:bg-black/70 text-red-400"
                              onClick={() => handleToggleFavorite("message", message.id)}
                            >
                              <Heart className="h-4 w-4 fill-current" />
                            </Button>
                          </div>
                          <div>
                            <h3 className="text-sm font-medium text-slate-900 dark:text-white line-clamp-2 mb-1">
                              {message.title}
                            </h3>
                            <p className="text-xs text-slate-600 dark:text-slate-400 mb-1">{message.speaker}</p>
                            <p className="text-xs text-slate-500">{message.duration}</p>
                          </div>
                        </>
                      ) : (
                        <>
                          <img
                            src={"/images/house-exterior.jpg"}
                            alt={message.title}
                            className="w-16 h-16 rounded-lg object-cover border border-slate-200 dark:border-slate-700"
                          />
                          <div className="flex-1">
                            <h3 className="font-medium text-slate-900 dark:text-white">{message.title}</h3>
                            <p className="text-sm text-slate-600 dark:text-slate-400">{message.speaker}</p>
                            <p className="text-xs text-slate-500">{message.duration}</p>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-red-400 hover:text-red-300"
                            onClick={() => handleToggleFavorite("message", message.id)}
                          >
                            <Heart className="h-4 w-4 fill-current" />
                          </Button>
                        </>
                      )}
                    </div>
                  ))}
                </div>
              </TabsContent>

              {/* Messages Only */}
              <TabsContent value="messages" className="mt-0">
                <div
                  className={
                    viewMode === "grid"
                      ? "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4"
                      : "space-y-3"
                  }
                >
                  {favoritesData.messages?.map((message) => (
                    <div
                      key={message.id}
                      className={
                        viewMode === "grid"
                          ? "group"
                          : "flex items-center gap-4 p-3 bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm rounded-lg border border-slate-200 dark:border-slate-700"
                      }
                    >
                      {viewMode === "grid" ? (
                        <>
                          <div className="relative aspect-[3/4] rounded-lg overflow-hidden mb-3 border border-slate-200 dark:border-slate-700">
                            <img
                              src={"/images/house-exterior.jpg"}
                              alt={message.title}
                              className="w-full h-full object-cover transition-transform group-hover:scale-105"
                            />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                              <Button
                                size="icon"
                                variant="secondary"
                                className="rounded-full h-10 w-10 bg-white/90 dark:bg-slate-800/90 text-slate-900 dark:text-white"
                              >
                                <Play className="h-5 w-5 ml-1" />
                              </Button>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="absolute top-2 right-2 h-8 w-8 bg-black/50 hover:bg-black/70 text-red-400"
                              onClick={() => handleToggleFavorite("message", message.id)}
                            >
                              <Heart className="h-4 w-4 fill-current" />
                            </Button>
                          </div>
                          <div>
                            <h3 className="text-sm font-medium text-slate-900 dark:text-white line-clamp-2 mb-1">
                              {message.title}
                            </h3>
                            <p className="text-xs text-slate-600 dark:text-slate-400 mb-1">{message.speaker}</p>
                            <p className="text-xs text-slate-500">{message.duration}</p>
                          </div>
                        </>
                      ) : (
                        <>
                          <img
                            src={"/images/house-exterior.jpg"}
                            alt={message.title}
                            className="w-16 h-16 rounded-lg object-cover border border-slate-200 dark:border-slate-700"
                          />
                          <div className="flex-1">
                            <h3 className="font-medium text-slate-900 dark:text-white">{message.title}</h3>
                            <p className="text-sm text-slate-600 dark:text-slate-400">{message.speaker}</p>
                            <p className="text-xs text-slate-500">{message.duration}</p>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-red-400 hover:text-red-300"
                            onClick={() => handleToggleFavorite("message", message.id)}
                          >
                            <Heart className="h-4 w-4 fill-current" />
                          </Button>
                        </>
                      )}
                    </div>
                  ))}
                </div>
              </TabsContent>

              {/* Podcasts Only */}
              <TabsContent value="podcasts" className="mt-0">
                <div
                  className={
                    viewMode === "grid"
                      ? "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4"
                      : "space-y-3"
                  }
                >
                  {favoritesData.podcasts?.map((podcast) => (
                    <div
                      key={podcast.id}
                      className={
                        viewMode === "grid"
                          ? "group"
                          : "flex items-center gap-4 p-3 bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm rounded-lg border border-slate-200 dark:border-slate-700"
                      }
                    >
                      {viewMode === "grid" ? (
                        <>
                          <div className="relative aspect-square rounded-lg overflow-hidden mb-3 border border-slate-200 dark:border-slate-700">
                            <img
                              src={"/images/house-exterior.jpg"}
                              alt={podcast.title}
                              className="w-full h-full object-cover transition-transform group-hover:scale-105"
                            />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                              <Button
                                size="icon"
                                variant="secondary"
                                className="rounded-full h-10 w-10 bg-white/90 dark:bg-slate-800/90 text-slate-900 dark:text-white"
                              >
                                <Play className="h-5 w-5 ml-1" />
                              </Button>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="absolute top-2 right-2 h-8 w-8 bg-black/50 hover:bg-black/70 text-red-400"
                              onClick={() => handleToggleFavorite("podcast", podcast.id)}
                            >
                              <Heart className="h-4 w-4 fill-current" />
                            </Button>
                          </div>
                          <div>
                            <h3 className="text-sm font-medium text-slate-900 dark:text-white line-clamp-2 mb-1">
                              {podcast.title}
                            </h3>
                            <p className="text-xs text-slate-600 dark:text-slate-400 mb-1">by {podcast.host}</p>
                            <p className="text-xs text-slate-500">{podcast.episodes} episodes</p>
                          </div>
                        </>
                      ) : (
                        <>
                          <img
                            src={"/images/house-exterior.jpg"}
                            alt={podcast.title}
                            className="w-16 h-16 rounded-lg object-cover border border-slate-200 dark:border-slate-700"
                          />
                          <div className="flex-1">
                            <h3 className="font-medium text-slate-900 dark:text-white">{podcast.title}</h3>
                            <p className="text-sm text-slate-600 dark:text-slate-400">by {podcast.host}</p>
                            <p className="text-xs text-slate-500">{podcast.episodes} episodes</p>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-red-400 hover:text-red-300"
                            onClick={() => handleToggleFavorite("podcast", podcast.id)}
                          >
                            <Heart className="h-4 w-4 fill-current" />
                          </Button>
                        </>
                      )}
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </TabsContent>

          {/* My Playlists Tab */}
          <TabsContent value="playlists" className="mt-0">
            <div className="mb-8">
              {/* Header with filters */}
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-6">
                <div className="flex items-center gap-4">
                  <h2 className="text-2xl font-bold text-slate-900 dark:text-white">My lists</h2>
                  <Dialog open={isCreatePlaylistOpen} onOpenChange={setIsCreatePlaylistOpen}>
                    <DialogTrigger asChild>
                      <Button className="bg-slate-700 hover:bg-slate-600 text-white dark:bg-slate-600 dark:hover:bg-slate-500">
                        <Plus className="mr-2 h-4 w-4" />
                        New list
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white">
                      <DialogHeader>
                        <DialogTitle>Create New Playlist</DialogTitle>
                        <DialogDescription className="text-slate-600 dark:text-slate-400">
                          Create a new playlist to organize your favorite content.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="playlist-name">Playlist Name</Label>
                          <Input
                            id="playlist-name"
                            value={newPlaylistName}
                            onChange={(e) => setNewPlaylistName(e.target.value)}
                            className="bg-slate-50 dark:bg-slate-700 border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white"
                            placeholder="Enter playlist name..."
                          />
                        </div>
                        <div>
                          <Label htmlFor="playlist-description">Description (Optional)</Label>
                          <Textarea
                            id="playlist-description"
                            value={newPlaylistDescription}
                            onChange={(e) => setNewPlaylistDescription(e.target.value)}
                            className="bg-slate-50 dark:bg-slate-700 border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white"
                            placeholder="Enter playlist description..."
                            rows={3}
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button
                          variant="outline"
                          onClick={() => setIsCreatePlaylistOpen(false)}
                          className="border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300"
                        >
                          Cancel
                        </Button>
                        <Button
                          onClick={handleCreatePlaylist}
                          disabled={!newPlaylistName.trim() || isCreatingPlaylist}
                          className="bg-primary hover:bg-primary/90"
                        >
                          {isCreatingPlaylist ? "Creating..." : "Create Playlist"}
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>

                <div className="flex items-center gap-4">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="outline"
                        className="bg-white/70 dark:bg-slate-800/70 border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white backdrop-blur-sm"
                      >
                        Sort by <ChevronDown className="ml-2 h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="bg-white/95 dark:bg-slate-800/95 border-slate-200 dark:border-slate-700 backdrop-blur-sm">
                      <DropdownMenuItem
                        onClick={() => setSortBy("recent")}
                        className="text-slate-900 dark:text-white hover:bg-slate-100 dark:hover:bg-slate-700"
                      >
                        Recently Added
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => setSortBy("alphabetical")}
                        className="text-slate-900 dark:text-white hover:bg-slate-100 dark:hover:bg-slate-700"
                      >
                        Alphabetical
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => setSortBy("count")}
                        className="text-slate-900 dark:text-white hover:bg-slate-100 dark:hover:bg-slate-700"
                      >
                        Item Count
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>

                  <div className="flex items-center bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm rounded-lg p-1 border border-slate-300 dark:border-slate-600">
                    <Button
                      variant={viewMode === "list" ? "default" : "ghost"}
                      size="icon"
                      onClick={() => setViewMode("list")}
                      className="h-8 w-8"
                    >
                      <List className="h-4 w-4" />
                    </Button>
                    <Button
                      variant={viewMode === "grid" ? "default" : "ghost"}
                      size="icon"
                      onClick={() => setViewMode("grid")}
                      className="h-8 w-8"
                    >
                      <Grid3X3 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Filter tabs */}
              <div className="flex items-center gap-2 mb-8">
                <Button
                  variant={activeFilter === "all" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setActiveFilter("all")}
                  className={
                    activeFilter === "all"
                      ? "bg-slate-700 text-white dark:bg-slate-600"
                      : "bg-white/70 dark:bg-slate-800/70 border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white backdrop-blur-sm"
                  }
                >
                  All
                </Button>
                <Button
                  variant={activeFilter === "by-you" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setActiveFilter("by-you")}
                  className={
                    activeFilter === "by-you"
                      ? "bg-slate-700 text-white dark:bg-slate-600"
                      : "bg-white/70 dark:bg-slate-800/70 border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white backdrop-blur-sm"
                  }
                >
                  By you
                </Button>
                <Button
                  variant={activeFilter === "seen-rated" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setActiveFilter("seen-rated")}
                  className={
                    activeFilter === "seen-rated"
                      ? "bg-slate-700 text-white dark:bg-slate-600"
                      : "bg-white/70 dark:bg-slate-800/70 border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white backdrop-blur-sm"
                  }
                >
                  Seen/Rated
                </Button>
                <Button
                  variant={activeFilter === "subscribed" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setActiveFilter("subscribed")}
                  className={
                    activeFilter === "subscribed"
                      ? "bg-slate-700 text-white dark:bg-slate-600"
                      : "bg-white/70 dark:bg-slate-800/70 border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white backdrop-blur-sm"
                  }
                >
                  Subscribed
                </Button>
              </div>
            </div>

            {/* Stacked Cards Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {filteredPlaylists.map((playlist) => (
                <div key={playlist.id} className="group cursor-pointer">
                  <div className="relative aspect-[4/3] mb-4">
                    {/* Stacked card effect */}
                    <div className="absolute inset-0 bg-slate-300/60 dark:bg-slate-700/80 rounded-lg transform rotate-1 scale-95"></div>
                    <div className="absolute inset-0 bg-slate-200/40 dark:bg-slate-600/60 rounded-lg transform -rotate-1 scale-97"></div>

                    {/* Main card */}
                    <div className="relative w-full h-full bg-white dark:bg-slate-800 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 group-hover:scale-105 transition-transform duration-200">
                      {playlist.count > 0 && playlist.images && playlist.images.length > 0 ? (
                        <div className="w-full h-full">
                          {playlist.images.length === 1 ? (
                            <img
                              src={"/images/house-exterior.jpg"}
                              alt={playlist.title}
                              className="w-full h-full object-cover"
                            />
                          ) : playlist.images.length === 2 ? (
                            <div className="grid grid-cols-2 h-full">
                              {playlist.images.slice(0, 2).map((image, index) => (
                                <img
                                  key={index}
                                  src={"/images/house-exterior.jpg"}
                                  alt={`${playlist.title} ${index + 1}`}
                                  className="w-full h-full object-cover"
                                />
                              ))}
                            </div>
                          ) : (
                            <div className="grid grid-cols-2 grid-rows-2 h-full">
                              {playlist.images.slice(0, 4).map((image, index) => (
                                <img
                                  key={index}
                                  src={"/images/house-exterior.jpg"}
                                  alt={`${playlist.title} ${index + 1}`}
                                  className="w-full h-full object-cover"
                                />
                              ))}
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-slate-100 dark:bg-slate-700">
                          <ListMusic className="h-12 w-12 text-slate-400 dark:text-slate-500" />
                        </div>
                      )}

                      {/* Hover overlay */}
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Button
                          size="icon"
                          variant="secondary"
                          className="rounded-full h-12 w-12 bg-white/90 dark:bg-slate-800/90 text-slate-900 dark:text-white"
                        >
                          <Play className="h-6 w-6 ml-1" />
                        </Button>
                      </div>

                      {/* More options button */}
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="absolute top-2 right-2 h-8 w-8 bg-black/50 hover:bg-black/70 text-white opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent className="bg-white/95 dark:bg-slate-800/95 border-slate-200 dark:border-slate-700 backdrop-blur-sm">
                          <DropdownMenuItem className="text-slate-900 dark:text-white hover:bg-slate-100 dark:hover:bg-slate-700">
                            <Edit className="mr-2 h-4 w-4" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-slate-900 dark:text-white hover:bg-slate-100 dark:hover:bg-slate-700">
                            <Share2 className="mr-2 h-4 w-4" />
                            Share
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-slate-900 dark:text-white hover:bg-slate-100 dark:hover:bg-slate-700">
                            <Download className="mr-2 h-4 w-4" />
                            Download
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            className="text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20"
                            onClick={() => handleDeletePlaylist(playlist.id, playlist.title)}
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>

                      {/* Privacy indicator */}
                      <div className="absolute bottom-2 left-2 flex items-center gap-1">
                        {playlist.isPublic ? (
                          <Eye className="h-3 w-3 text-white/80" />
                        ) : (
                          <EyeOff className="h-3 w-3 text-white/80" />
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Playlist info */}
                  <div className="space-y-1">
                    <h3 className="text-slate-900 dark:text-white font-medium text-sm line-clamp-1">
                      {playlist.title}
                    </h3>
                    <p className="text-slate-600 dark:text-slate-400 text-xs">{playlist.count} Titles</p>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Recently Played Tab */}
          <TabsContent value="history" className="mt-0">
            <div className="text-center py-20">
              <Clock className="mx-auto h-16 w-16 text-slate-400 dark:text-slate-500 mb-6" />
              <h3 className="text-2xl font-medium text-slate-900 dark:text-white mb-3">No recent activity</h3>
              <p className="text-slate-600 dark:text-slate-400 mb-8 max-w-md mx-auto">
                Your recently played content will appear here. Start listening to build your history.
              </p>
              <Button asChild className="bg-primary hover:bg-primary/90">
                <Link to="/">Start Listening</Link>
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
