"use client"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import {
  User,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Bell,
  Shield,
  Heart,
  Download,
  Upload,
  Mic,
  BookOpen,
  ListMusic,
  Edit,
  Save,
  X,
  Camera,
  Loader2,
} from "lucide-react"
import { useAuthStore } from "../store/authStore"
import { toast } from "sonner"

export default function ProfilePage() {
  const { user, setUser } = useAuthStore()
  const [isEditing, setIsEditing] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    name: user?.name || "",
    email: user?.email || "",
    phone: user?.phone || "",
    location: user?.location || "",
    bio: user?.bio || "",
    date_of_birth: user?.date_of_birth || "",
  })

  const [notifications, setNotifications] = useState({
    email_messages: true,
    email_podcasts: true,
    push_notifications: true,
    weekly_digest: false,
  })

  const [privacy, setPrivacy] = useState({
    profile_visibility: "public",
    show_favorites: true,
    show_activity: false,
  })

  // Mock user stats
  const userStats = {
    favorites: 24,
    downloads: 12,
    uploads: 3,
    listens: 156,
    comments: 8,
    playlists: 2,
  }

  // Mock recent activity
  const recentActivity = [
    {
      id: 1,
      type: "favorite",
      title: "Added 'The Power of Faith' to favorites",
      date: "2 hours ago",
      icon: <Heart className="h-4 w-4 text-red-500" />,
    },
    {
      id: 2,
      type: "download",
      title: "Downloaded 'Walking in Divine Health'",
      date: "1 day ago",
      icon: <Download className="h-4 w-4 text-blue-500" />,
    },
    {
      id: 3,
      type: "comment",
      title: "Commented on 'Faith Foundations Podcast'",
      date: "3 days ago",
      icon: <BookOpen className="h-4 w-4 text-green-500" />,
    },
    {
      id: 4,
      type: "playlist",
      title: "Created playlist 'Morning Devotions'",
      date: "1 week ago",
      icon: <ListMusic className="h-4 w-4 text-purple-500" />,
    },
  ]

  const handleSaveProfile = async () => {
    setIsLoading(true)
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Update user in store
      setUser({ ...user, ...formData })
      setIsEditing(false)
      toast.success("Profile updated successfully!")
    } catch (error) {
      toast.error("Failed to update profile")
    } finally {
      setIsLoading(false)
    }
  }

  const handleCancelEdit = () => {
    setFormData({
      name: user?.name || "",
      email: user?.email || "",
      phone: user?.phone || "",
      location: user?.location || "",
      bio: user?.bio || "",
      date_of_birth: user?.date_of_birth || "",
    })
    setIsEditing(false)
  }

  const handleAvatarUpload = () => {
    // Implement avatar upload
    toast.info("Avatar upload feature coming soon!")
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="grid lg:grid-cols-3 gap-8">
        {/* Profile Sidebar */}
        <div className="lg:col-span-1 space-y-6">
          {/* Profile Card */}
          <Card>
            <CardContent className="p-6 text-center">
              <div className="relative inline-block mb-4">
                <Avatar className="h-24 w-24">
                  <AvatarImage src={user?.avatar || "/placeholder.svg"} />
                  <AvatarFallback className="text-2xl">{user?.name?.charAt(0) || "U"}</AvatarFallback>
                </Avatar>
                <Button
                  size="sm"
                  variant="outline"
                  className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full p-0 bg-transparent"
                  onClick={handleAvatarUpload}
                >
                  <Camera className="h-4 w-4" />
                </Button>
              </div>
              <h2 className="text-xl font-semibold mb-1">{user?.name || "User"}</h2>
              <p className="text-muted-foreground mb-4">{user?.email}</p>
              <Badge variant="secondary" className="mb-4">
                {user?.role || "Member"}
              </Badge>
              <p className="text-sm text-muted-foreground">
                Member since {new Date(user?.created_at || Date.now()).toLocaleDateString()}
              </p>
            </CardContent>
          </Card>

          {/* Stats Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Your Activity</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-500">{userStats.favorites}</div>
                  <div className="text-xs text-muted-foreground">Favorites</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-500">{userStats.downloads}</div>
                  <div className="text-xs text-muted-foreground">Downloads</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-500">{userStats.listens}</div>
                  <div className="text-xs text-muted-foreground">Listens</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-500">{userStats.playlists}</div>
                  <div className="text-xs text-muted-foreground">Playlists</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Recent Activity</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-start gap-3">
                  <div className="mt-0.5">{activity.icon}</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium line-clamp-2">{activity.title}</p>
                    <p className="text-xs text-muted-foreground">{activity.date}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-2">
          <Tabs defaultValue="profile" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="profile">
                <User className="h-4 w-4 mr-2" />
                Profile
              </TabsTrigger>
              <TabsTrigger value="notifications">
                <Bell className="h-4 w-4 mr-2" />
                Notifications
              </TabsTrigger>
              <TabsTrigger value="privacy">
                <Shield className="h-4 w-4 mr-2" />
                Privacy
              </TabsTrigger>
              <TabsTrigger value="uploads">
                <Upload className="h-4 w-4 mr-2" />
                My Uploads
              </TabsTrigger>
            </TabsList>

            {/* Profile Tab */}
            <TabsContent value="profile">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>Profile Information</CardTitle>
                    <CardDescription>Update your personal information and bio</CardDescription>
                  </div>
                  {!isEditing ? (
                    <Button onClick={() => setIsEditing(true)}>
                      <Edit className="h-4 w-4 mr-2" />
                      Edit
                    </Button>
                  ) : (
                    <div className="flex gap-2">
                      <Button variant="outline" onClick={handleCancelEdit} disabled={isLoading}>
                        <X className="h-4 w-4 mr-2" />
                        Cancel
                      </Button>
                      <Button onClick={handleSaveProfile} disabled={isLoading}>
                        {isLoading ? (
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        ) : (
                          <Save className="h-4 w-4 mr-2" />
                        )}
                        Save
                      </Button>
                    </div>
                  )}
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="name"
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          disabled={!isEditing}
                          className="pl-10"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          disabled={!isEditing}
                          className="pl-10"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="phone"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          disabled={!isEditing}
                          className="pl-10"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="location">Location</Label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="location"
                          value={formData.location}
                          onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                          disabled={!isEditing}
                          className="pl-10"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="date_of_birth">Date of Birth</Label>
                      <div className="relative">
                        <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="date_of_birth"
                          type="date"
                          value={formData.date_of_birth}
                          onChange={(e) => setFormData({ ...formData, date_of_birth: e.target.value })}
                          disabled={!isEditing}
                          className="pl-10"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea
                      id="bio"
                      placeholder="Tell us about yourself..."
                      value={formData.bio}
                      onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                      disabled={!isEditing}
                      className="min-h-[100px]"
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Notifications Tab */}
            <TabsContent value="notifications">
              <Card>
                <CardHeader>
                  <CardTitle>Notification Preferences</CardTitle>
                  <CardDescription>Choose how you want to be notified about new content and updates</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Email notifications for new messages</Label>
                        <p className="text-sm text-muted-foreground">Get notified when new messages are published</p>
                      </div>
                      <Switch
                        checked={notifications.email_messages}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, email_messages: checked })}
                      />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Email notifications for new podcasts</Label>
                        <p className="text-sm text-muted-foreground">
                          Get notified when new podcast episodes are available
                        </p>
                      </div>
                      <Switch
                        checked={notifications.email_podcasts}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, email_podcasts: checked })}
                      />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Push notifications</Label>
                        <p className="text-sm text-muted-foreground">Receive push notifications on your device</p>
                      </div>
                      <Switch
                        checked={notifications.push_notifications}
                        onCheckedChange={(checked) =>
                          setNotifications({ ...notifications, push_notifications: checked })
                        }
                      />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Weekly digest</Label>
                        <p className="text-sm text-muted-foreground">
                          Get a weekly summary of new content and your activity
                        </p>
                      </div>
                      <Switch
                        checked={notifications.weekly_digest}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, weekly_digest: checked })}
                      />
                    </div>
                  </div>
                  <Button className="w-full">Save Notification Preferences</Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Privacy Tab */}
            <TabsContent value="privacy">
              <Card>
                <CardHeader>
                  <CardTitle>Privacy Settings</CardTitle>
                  <CardDescription>Control who can see your profile and activity</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Show favorites publicly</Label>
                        <p className="text-sm text-muted-foreground">
                          Allow others to see your favorite messages and podcasts
                        </p>
                      </div>
                      <Switch
                        checked={privacy.show_favorites}
                        onCheckedChange={(checked) => setPrivacy({ ...privacy, show_favorites: checked })}
                      />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Show activity</Label>
                        <p className="text-sm text-muted-foreground">Display your recent activity on your profile</p>
                      </div>
                      <Switch
                        checked={privacy.show_activity}
                        onCheckedChange={(checked) => setPrivacy({ ...privacy, show_activity: checked })}
                      />
                    </div>
                  </div>
                  <Button className="w-full">Save Privacy Settings</Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* My Uploads Tab */}
            <TabsContent value="uploads">
              <Card>
                <CardHeader>
                  <CardTitle>My Uploads</CardTitle>
                  <CardDescription>Manage your uploaded podcasts and content</CardDescription>
                </CardHeader>
                <CardContent>
                  {userStats.uploads > 0 ? (
                    <div className="space-y-4">
                      {/* Mock uploaded content */}
                      <div className="flex items-center gap-4 p-4 border rounded-lg">
                        <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                          <Mic className="h-6 w-6 text-primary" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium">Faith Foundations Podcast</h4>
                          <p className="text-sm text-muted-foreground">Uploaded 2 weeks ago • 15 episodes</p>
                        </div>
                        <Badge variant="secondary">Approved</Badge>
                        <Button variant="outline" size="sm">
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Upload className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                      <h3 className="text-lg font-semibold mb-2">No uploads yet</h3>
                      <p className="text-muted-foreground mb-6">Request upload rights to start sharing your content</p>
                      <Button>Request Upload Rights</Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
