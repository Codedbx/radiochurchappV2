"use client"
import { useEffect, useRef, useState } from "react"
import { Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  MessageCircle,
  Play,
  Phone,
  Pause,
  Volume2,
  VolumeX,
  Heart,
  ExternalLink,
  Clock,
  Send,
  MapPin,
  Loader2,
  Copy,
  Home,
  Calendar,
  Mic,
  BookOpen,
  Tag,
  ArrowRight,
  ListMusic,
  Star,
  Bookmark,
  Gift,
} from "lucide-react"
import { Slider } from "@/components/ui/slider"
import Marquee from "react-fast-marquee"
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { motion } from "framer-motion"
import MobileCompactPlayer from "@/components/MobileCompactPlayer"

export default function HomePage() {
  const audioRef = useRef(null)

  // Audio player states for desktop
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [isLiked, setIsLiked] = useState(false)
  const [volume, setVolume] = useState(80)
  const [isLoadingAudio, setIsLoadingAudio] = useState(false)
  const [audioError, setAudioError] = useState(null)

  // Comment states for desktop
  const [commentText, setCommentText] = useState("")
  const [comments, setComments] = useState([])
  const [isPostingComment, setIsPostingComment] = useState(false)
  const [commentPostError, setCommentPostError] = useState(null)

  // Determine if today is Sunday or Wednesday in WAT
  const watDate = new Date(new Date().toLocaleString("en-US", { timeZone: "Africa/Lagos" }))
  const day = watDate.getDay()
  const hour = watDate.getHours()
  const isMidWeekService = day === 3 && hour >= 18 && hour < 19
  const isSundayService = day === 0 && hour >= 7 && hour < 8

  // Simulate fetching comments on mount
  useEffect(() => {
    const fetchComments = async () => {
      try {
        await new Promise((resolve) => setTimeout(resolve, 1500))
        setComments([
          {
            id: 1,
            name: "Sarah Johnson",
            text: "Beautiful service today! God bless 🙏",
            time: "2 minutes ago",
            avatar: "SJ",
          },
          {
            id: 2,
            name: "Michael David",
            text: "Powerful message from Pastor. Thank you for this ministry!",
            time: "5 minutes ago",
            avatar: "MD",
          },
          {
            id: 3,
            name: "Grace Emmanuel",
            text: "Listening from Lagos. God bless everyone ❤️",
            time: "8 minutes ago",
            avatar: "GE",
          },
        ])
      } catch (error) {
        console.error("Error fetching comments:", error)
      }
    }
    fetchComments()
  }, [])

  // Audio control effects for desktop
  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const handleCanPlay = () => setIsLoadingAudio(false)
    const handleWaiting = () => setIsLoadingAudio(true)
    const handleError = (e) => {
      console.error("Audio error:", e)
      setAudioError("Failed to load audio. Please try again.")
      setIsLoadingAudio(false)
      setIsPlaying(false)
    }

    audio.addEventListener("canplay", handleCanPlay)
    audio.addEventListener("waiting", handleWaiting)
    audio.addEventListener("error", handleError)

    if (isPlaying) {
      if (audio.paused) {
        setIsLoadingAudio(true)
        audio.play().catch((e) => {
          console.error("Error attempting to play audio:", e)
          setAudioError("Playback failed. Please try clicking play again.")
          setIsLoadingAudio(false)
          setIsPlaying(false)
        })
      }
    } else {
      if (!audio.paused) {
        audio.pause()
      }
    }

    return () => {
      audio.removeEventListener("canplay", handleCanPlay)
      audio.removeEventListener("waiting", handleWaiting)
      audio.removeEventListener("error", handleError)
    }
  }, [isPlaying])

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.muted = isMuted
    }
  }, [isMuted])

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume / 100
    }
  }, [volume])

  const togglePlayPause = () => {
    setIsPlaying((prev) => !prev)
    setAudioError(null)
  }

  const toggleMute = () => {
    setIsMuted((prev) => !prev)
  }

  const toggleLike = () => {
    setIsLiked((prev) => !prev)
  }

  const handleSubmitComment = async () => {
    if (commentText.trim()) {
      setIsPostingComment(true)
      setCommentPostError(null)
      try {
        await new Promise((resolve) => setTimeout(resolve, 1000))
        const newComment = {
          id: comments.length + 1,
          name: "You",
          text: commentText,
          time: "Just now",
          avatar: "YO",
        }
        setComments((prev) => [newComment, ...prev])
        setCommentText("")
      } catch (error) {
        setCommentPostError("Failed to post comment. Please try again.")
        console.error("Error posting comment:", error)
      } finally {
        setIsPostingComment(false)
      }
    }
  }

  const marqueeContent = () => {
    if (isSundayService) {
      return (
        <span className="flex items-center gap-2">
          <Clock className="h-4 w-4 text-primary" />
          <span className="font-semibold text-primary">Live Sunday Service:</span> Join us now for a powerful time in
          God's presence!
        </span>
      )
    } else if (isMidWeekService) {
      return (
        <span className="flex items-center gap-2">
          <Clock className="h-4 w-4 text-primary" />
          <span className="font-semibold text-primary">Live Mid-Week Service:</span> Tune in for an inspiring session of
          prayer and teaching!
        </span>
      )
    } else {
      return (
        <span className="flex items-center gap-2">
          <MapPin className="h-4 w-4 text-primary" />
          <span className="font-semibold text-primary">Welcome to Online Radio Church!</span> Stay connected for daily
          inspirations and live programs. God bless you!
        </span>
      )
    }
  }

  // Dummy data
  const upcomingPrograms = [
    {
      id: 1,
      title: "Global Communion Service",
      date: "August 4, 2025",
      time: "5:00 PM WAT",
      description: "Join Pastor Chris for a special time of communion.",
      image: "/placeholder.svg?height=120&width=200",
    },
    {
      id: 2,
      title: "Your LoveWorld Specials",
      date: "August 10-14, 2025",
      time: "7:00 PM WAT Daily",
      description: "A series of profound teachings and revelations.",
      image: "/placeholder.svg?height=120&width=200",
    },
    {
      id: 3,
      title: "Healing School Summer Session",
      date: "September 1, 2025",
      time: "Ongoing",
      description: "Register now to experience God's healing power.",
      image: "/placeholder.svg?height=120&width=200",
    },
  ]

  const messages = [
    {
      id: 1,
      title: "The Power of Your Mind",
      speaker: "Pastor Chris Oyakhilome",
      duration: "1:15:30",
      image: "/placeholder.svg?height=120&width=200",
    },
    {
      id: 2,
      title: "Recreating Your World",
      speaker: "Pastor Chris Oyakhilome",
      duration: "0:58:10",
      image: "/placeholder.svg?height=120&width=200",
    },
    {
      id: 3,
      title: "The Holy Spirit and You",
      speaker: "Pastor Chris Oyakhilome",
      duration: "1:05:00",
      image: "/placeholder.svg?height=120&width=200",
    },
  ]

  const podcasts = [
    {
      id: 1,
      title: "Faith Foundations",
      host: "Pastor Sarah",
      episode: "Faith for the Future",
      image: "/placeholder.svg?height=120&width=120",
      rating: 4,
    },
    {
      id: 2,
      title: "Spiritual Growth",
      host: "Pastor Michael",
      episode: "Understanding Righteousness",
      image: "/placeholder.svg?height=120&width=120",
      rating: 5,
    },
    {
      id: 3,
      title: "Kingdom Living",
      host: "Pastor Grace",
      episode: "Global Impact Report",
      image: "/placeholder.svg?height=120&width=120",
      rating: 4,
    },
    {
      id: 4,
      title: "Divine Wisdom",
      host: "Pastor David",
      episode: "Nature's Wisdom",
      image: "/placeholder.svg?height=120&width=120",
      rating: 5,
    },
  ]

  const playlists = [
    {
      id: 1,
      title: "Worship Anthems",
      description: "A collection of powerful worship songs to uplift your spirit.",
      image: "/placeholder.svg?height=120&width=200",
      count: 15,
    },
    {
      id: 2,
      title: "Healing Declarations",
      description: "Messages and confessions for divine health and healing.",
      image: "/placeholder.svg?height=120&width=200",
      count: 10,
    },
    {
      id: 3,
      title: "Prosperity Teachings",
      description: "Unlock the principles of financial abundance and success.",
      image: "/placeholder.svg?height=120&width=200",
      count: 8,
    },
    {
      id: 4,
      title: "Youth Empowerment",
      description: "Inspiring messages for young people to live victoriously.",
      image: "/placeholder.svg?height=120&width=200",
      count: 12,
    },
  ]

  const categories = [
    { id: 1, name: "Faith", icon: <Heart className="h-5 w-5" /> },
    { id: 2, name: "Healing", icon: <Volume2 className="h-5 w-5" /> },
    { id: 3, name: "Prayer", icon: <MessageCircle className="h-5 w-5" /> },
    { id: 4, name: "Prosperity", icon: <Copy className="h-5 w-5" /> },
    { id: 5, name: "Salvation", icon: <Home className="h-5 w-5" /> },
  ]

  return (
    <>
      {/* Audio Element for Desktop */}
      <audio ref={audioRef} preload="auto">
        <source src="https://radio.ifastekpanel.com:1115/stream" type="audio/mpeg" />
        Your browser does not support the audio element.
      </audio>

      {/* DESKTOP VERSION - Hidden on mobile */}
      <div className="hidden lg:block min-h-screen bg-gradient-to-br from-slate-100 via-white to-violet-50/30 dark:from-slate-900 dark:via-slate-800 dark:to-violet-900/10">
        <div className="container mx-auto max-w-[90rem] px-4 py-8">
          <div className="flex flex-col gap-8 lg:flex-row">
            {/* Left Sidebar - Radio Player (Sticky) */}
            <div className="lg:sticky lg:top-24 lg:w-96 lg:self-start">
              <Card className="gap-0 border-0 bg-white shadow-xl backdrop-blur-sm dark:bg-slate-800/70">
                <CardHeader className="pb-6 text-center">
                  <div className="relative mx-auto">
                    <div className="absolute inset-0 animate-pulse rounded-full blur-2xl bg-gradient-to-r from-violet-500/20 to-purple-500/20" />
                    <div className="relative flex h-40 w-40 items-center justify-center rounded-full border-4 border-white/50 bg-gradient-to-br from-violet-50 to-purple-50 p-6 shadow-2xl dark:border-slate-700/50 dark:from-violet-900/30 dark:to-purple-900/30">
                      <img src="/images/logo.png" alt="logo" />
                    </div>
                  </div>
                  <CardTitle className="text-2xl font-bold text-foreground">Online Radio Church</CardTitle>
                  <p className="mx-auto max-w-xs text-lg text-slate-600 dark:text-slate-400">
                    Christ Embassy Nigeria South South Zone 1
                  </p>
                  <div className="mt-2 flex items-center justify-center gap-2">
                    <div className="h-2 w-2 animate-pulse rounded-full bg-red-500" />
                    <span className="text-sm text-slate-500">On Air</span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Play Controls */}
                  <div className="flex items-center justify-center gap-6">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={toggleLike}
                      className={`h-12 w-12 rounded-full transition-all duration-300 ${
                        isLiked
                          ? "border-red-200 bg-red-50 text-red-600 hover:bg-red-100"
                          : "hover:bg-slate-50 dark:hover:bg-slate-700"
                      }`}
                    >
                      <Heart className={`h-5 w-5 ${isLiked ? "fill-current" : ""}`} />
                    </Button>
                    <Button
                      onClick={togglePlayPause}
                      className="h-20 w-20 rounded-full bg-gradient-to-r from-primary to-primary/70 shadow-2xl transition-all duration-300 hover:scale-105 hover:shadow-violet-500/25"
                    >
                      {isLoadingAudio && isPlaying ? (
                        <Loader2 className="h-8 w-8 animate-spin text-white" />
                      ) : isPlaying ? (
                        <Pause className="h-8 w-8" />
                      ) : (
                        <Play className="h-8 w-8 ml-1" />
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={toggleMute}
                      className="h-12 w-12 rounded-full bg-transparent transition-all duration-300 hover:bg-slate-50 dark:hover:bg-slate-700"
                    >
                      {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                    </Button>
                  </div>

                  {audioError && (
                    <div className="rounded-lg bg-red-50 p-3 text-center dark:bg-red-900/20">
                      <p className="text-sm text-red-600 dark:text-red-400">{audioError}</p>
                    </div>
                  )}

                  {/* Volume Control */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm text-slate-600 dark:text-slate-400">
                      <span>Volume</span>
                      <span>{volume}%</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <VolumeX className="h-4 w-4 text-slate-400" />
                      <Slider
                        value={[volume]}
                        max={100}
                        step={1}
                        onValueChange={(value) => setVolume(value[0])}
                        className="flex-1"
                      />
                      <Volume2 className="h-4 w-4 text-slate-400" />
                    </div>
                  </div>

                  {/* Call to Action */}
                  <div className="space-y-3 border-t border-slate-200/50 pt-6 dark:border-slate-700/50">
                    <Button
                      variant="outline"
                      className="w-full rounded-lg border-green-200 bg-gradient-to-r from-green-50 to-emerald-50 text-green-700 hover:from-green-100 hover:to-emerald-100 dark:border-green-800 dark:from-green-900/20 dark:to-emerald-900/20 dark:text-green-400"
                      asChild
                    >
                      <a href="tel:+2347042066472" className="flex items-center justify-center gap-2">
                        <Phone className="h-4 w-4" />
                        Call In: +234 704 206 6472
                      </a>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right Content Area */}
            <div className="min-w-0 flex-1 overflow-hidden">
              <Tabs defaultValue="comments" className="h-full">
                <TabsList className="grid h-14 w-full grid-cols-4 rounded-none border-b border-slate-200 bg-transparent p-0 dark:border-slate-700">
                  <TabsTrigger
                    value="home"
                    className="relative -mb-px rounded-none px-4 py-3 text-center text-slate-600 transition-colors duration-200 data-[state=active]:border-b-2 data-[state=active]:border-b-gray-600 data-[state=active]:font-semibold data-[state=active]:shadow-lg hover:text-primary/80 dark:text-slate-400 dark:data-[state=active]:border-none dark:data-[state=active]:shadow-none"
                  >
                    <Home className="mr-2 h-4 w-4" />
                    Home
                  </TabsTrigger>
                  <TabsTrigger
                    value="comments"
                    className="relative -mb-px rounded-none px-4 py-3 text-center text-slate-600 transition-colors duration-200 data-[state=active]:border-b-2 data-[state=active]:border-b-gray-600 data-[state=active]:font-semibold data-[state=active]:shadow-lg hover:text-primary/80 dark:text-slate-400 dark:data-[state=active]:border-none dark:data-[state=active]:shadow-none"
                  >
                    <MessageCircle className="mr-2 h-4 w-4" />
                    Comments
                  </TabsTrigger>
                  <TabsTrigger
                    value="give"
                    className="relative -mb-px rounded-none px-4 py-3 text-center text-slate-600 transition-colors duration-200 data-[state=active]:border-b-2 data-[state=active]:border-b-gray-600 data-[state=active]:font-semibold data-[state=active]:shadow-lg hover:text-primary/80 dark:text-slate-400 dark:data-[state=active]:border-none dark:data-[state=active]:shadow-none"
                  >
                    <Gift className="mr-2 h-4 w-4" />
                    Give
                  </TabsTrigger>
                  <TabsTrigger
                    value="links"
                    className="relative -mb-px rounded-none px-4 py-3 text-center text-slate-600 transition-colors duration-200 data-[state=active]:border-b-2 data-[state=active]:border-b-gray-600 data-[state=active]:font-semibold data-[state=active]:shadow-lg hover:text-primary/80 dark:text-slate-400 dark:data-[state=active]:border-none dark:data-[state=active]:shadow-none"
                  >
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Quick Links
                  </TabsTrigger>
                </TabsList>

                {/* Home Tab */}
                <TabsContent value="home" className="mt-4">
                  {/* Hero Section */}
                  <div className="relative h-64 w-full overflow-hidden rounded-xl bg-slate-900 shadow-lg md:h-80 lg:h-96">
                    <img
                      src="/images/house-exterior.jpg"
                      alt="Hero Background"
                      className="absolute inset-0 h-full w-full object-cover opacity-50"
                    />
                    <div className="pointer-events-none absolute bottom-0 left-0 right-0 h-full bg-gradient-to-b from-transparent to-slate-800"></div>
                    <div className="relative z-10 flex h-full flex-col justify-end p-6 md:max-w-2xl">
                      <h2 className="mb-2 text-3xl font-semibold text-white">
                        Healing Streams live and Healing Streams Special with the man of God Pastor Chris...
                      </h2>
                      <p className="text-lg text-white/85">
                        Experience divine healing and miracles as Pastor Chris ministers with power and demonstration of
                        the Spirit.
                      </p>
                      <div className="mt-4 flex gap-2">
                        <span className="h-2 w-2 rounded-full bg-primary"></span>
                        <span className="h-2 w-2 rounded-full bg-slate-500"></span>
                        <span className="h-2 w-2 rounded-full bg-slate-500"></span>
                        <span className="h-2 w-2 rounded-full bg-slate-500"></span>
                        <span className="h-2 w-2 rounded-full bg-slate-500"></span>
                      </div>
                    </div>
                  </div>

                  {/* Marquee Announcement */}
                  <div className="mt-4 overflow-hidden rounded-xl bg-gradient-to-r from-violet-50 to-purple-50 p-3 text-sm text-slate-800 shadow-lg dark:from-violet-900/20 dark:to-purple-900/20 dark:text-slate-200">
                    <Marquee gradient={false} speed={40} pauseOnHover>
                      <div className="flex items-center gap-8 whitespace-nowrap">
                        {marqueeContent()}
                        <span className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-primary" />
                          <span className="font-semibold text-primary">Sunday Service:</span> Every Sunday 7am to 8am
                          WAT
                        </span>
                        <span className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-primary" />
                          <span className="font-semibold text-primary">Mid-Week Service:</span> Every Wednesday 6pm to
                          7pm WAT
                        </span>
                        <span className="mr-8 flex items-center gap-2">
                          <Heart className="h-4 w-4 text-primary" />
                          <span className="font-semibold text-primary">Thank you for your support!</span> Your giving
                          helps us reach more souls.
                        </span>
                      </div>
                    </Marquee>
                  </div>

                  {/* Upcoming Programs */}
                  <Card className="mt-8 bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-r from-primary/80 to-primary/70">
                          <Calendar className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <h2 className="text-xl font-semibold">Upcoming Programs</h2>
                          <p className="text-sm text-slate-600 dark:text-slate-400">Don't miss out!</p>
                        </div>
                      </div>
                      <Link
                        to="/upcoming-programs"
                        className="flex items-center gap-1 text-sm font-medium text-primary hover:underline"
                      >
                        See More <ArrowRight className="h-4 w-4" />
                      </Link>
                    </CardHeader>
                    <CardContent className="p-6 pt-0">
                      <Carousel className="w-full">
                        <CarouselContent className="-ml-4">
                          {upcomingPrograms.map((program) => (
                            <CarouselItem key={program.id} className="basis-1/2 pl-4 md:basis-1/3 lg:basis-1/4">
                              <Card className="h-full gap-0 overflow-hidden py-0">
                                <img
                                  src="/images/house-exterior.jpg"
                                  alt={program.title}
                                  className="h-24 w-full object-cover"
                                />
                                <CardContent className="flex flex-col gap-2 p-4">
                                  <h3 className="text-base font-semibold">{program.title}</h3>
                                  <p className="text-xs text-slate-600 dark:text-slate-400">
                                    <Clock className="mr-1 inline-block h-3 w-3" />
                                    {program.date} at {program.time}
                                  </p>
                                  <p className="line-clamp-2 text-xs text-slate-700 dark:text-slate-300">
                                    {program.description}
                                  </p>
                                </CardContent>
                              </Card>
                            </CarouselItem>
                          ))}
                        </CarouselContent>
                        <CarouselPrevious className="translate-x-8" />
                        <CarouselNext className="-translate-x-8" />
                      </Carousel>
                    </CardContent>
                  </Card>

                  {/* Messages Overview */}
                  <Card className="mt-8 bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-r from-primary/80 to-primary/70">
                          <BookOpen className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <h2 className="text-xl font-semibold">Messages & Teachings</h2>
                          <p className="text-sm text-slate-600 dark:text-slate-400">Grow in the Word</p>
                        </div>
                      </div>
                      <Link
                        to="/messages"
                        className="flex items-center gap-1 text-sm font-medium text-primary hover:underline"
                      >
                        See More <ArrowRight className="h-4 w-4" />
                      </Link>
                    </CardHeader>
                    <CardContent className="p-6 pt-0">
                      <Carousel className="w-full">
                        <CarouselContent className="-ml-4">
                          {messages.map((message) => (
                            <CarouselItem key={message.id} className="basis-1/2 pl-4 md:basis-1/3 lg:basis-1/4">
                              <Card className="h-full overflow-hidden p-0 gap-0 rounded-lg shadow-md transition-all duration-300 hover:shadow-lg">
                                <img
                                  src="/images/house-exterior.jpg"
                                  alt={message.title}
                                  className="h-32 w-full rounded-t-lg object-cover"
                                />
                                <CardContent className="flex flex-col gap-2 p-4">
                                  <h3 className="line-clamp-2 text-base font-semibold text-slate-900 dark:text-slate-100">
                                    {message.title}
                                  </h3>
                                  <p className="text-sm text-slate-600 dark:text-slate-400">{message.speaker}</p>
                                  <p className="text-xs text-slate-500 dark:text-slate-500">{message.duration}</p>
                                </CardContent>
                              </Card>
                            </CarouselItem>
                          ))}
                        </CarouselContent>
                        <CarouselPrevious className="translate-x-8" />
                        <CarouselNext className="-translate-x-8" />
                      </Carousel>
                    </CardContent>
                  </Card>

                  {/* Podcasts */}
                  <Card className="mt-8 bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-r from-primary/80 to-primary/70">
                          <Mic className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <h2 className="text-xl font-semibold">Featured Podcasts</h2>
                          <p className="text-sm text-slate-600 dark:text-slate-400">Listen on the go</p>
                        </div>
                      </div>
                      <Link
                        to="/podcasts"
                        className="flex items-center gap-1 text-sm font-medium text-primary hover:underline"
                      >
                        View All <ArrowRight className="h-4 w-4" />
                      </Link>
                    </CardHeader>
                    <CardContent className="p-6 pt-0">
                      <Carousel className="w-full">
                        <CarouselContent className="-ml-4">
                          {podcasts.map((podcast) => (
                            <CarouselItem key={podcast.id} className="basis-1/2 pl-4 md:basis-1/3 lg:basis-1/3">
                              <Card className="relative h-[12rem] p-4 overflow-hidden rounded-lg bg-card shadow-md transition-all duration-300 hover:shadow-lg">
                                <div className="absolute right-4 top-4">
                                  <Mic className="h-5 w-5 text-accent-foreground" />
                                </div>
                                <div className="flex items-center gap-4 h-full">
                                  <img
                                    src="/images/house-exterior.jpg"
                                    alt={podcast.title}
                                    className="h-full w-28 flex-shrink-0 rounded-md object-cover shadow-lg"
                                  />
                                  <div className="flex flex-col gap-1">
                                    <div className="flex items-center gap-1">
                                      {Array.from({ length: 5 }).map((_, i) => (
                                        <Star
                                          key={i}
                                          size={14}
                                          className={`${
                                            i < podcast.rating ? "fill-yellow-500 text-yellow-500" : "text-gray-300"
                                          }`}
                                        />
                                      ))}
                                    </div>
                                    <h3 className="line-clamp-1 font-medium dark:text-slate-200">{podcast.title}</h3>
                                    <p className="text-sm text-slate-700 dark:text-slate-300">{podcast.host}</p>
                                    <Button variant="secondary" size="sm" className="mt-2 w-fit rounded-full text-xs">
                                      Listen Now
                                    </Button>
                                  </div>
                                </div>
                              </Card>
                            </CarouselItem>
                          ))}
                        </CarouselContent>
                        <CarouselPrevious className="translate-x-8" />
                        <CarouselNext className="-translate-x-8" />
                      </Carousel>
                    </CardContent>
                  </Card>

                  {/* Playlists */}
                  <Card className="mt-8 bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-r from-primary/80 to-primary/70">
                          <ListMusic className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <h2 className="text-xl font-semibold">Playlists</h2>
                          <p className="text-sm text-slate-600 dark:text-slate-400">Curated collections for you</p>
                        </div>
                      </div>
                      <Link
                        to="/playlists"
                        className="flex items-center gap-1 text-sm font-medium text-primary hover:underline"
                      >
                        See More <ArrowRight className="h-4 w-4" />
                      </Link>
                    </CardHeader>
                    <CardContent className="p-6 pt-0">
                      <Carousel className="w-full">
                        <CarouselContent className="-ml-4 gap-6">
                          {playlists.map((playlist) => (
                            <CarouselItem key={playlist.id} className="basis-1/2 pl-4 md:basis-1/3 lg:basis-1/4">
                              <div className="relative h-[8rem] w-full">
                                {/* Stacked background cards */}
                                <div className="absolute inset-x-0 top-0 h-full translate-x-6 translate-y-2 transform rounded-md bg-slate-300 shadow-lg dark:bg-slate-700"></div>
                                <div className="absolute inset-x-0 top-0 h-full translate-x-3 translate-y-1 transform rounded-md bg-slate-400 shadow-lg dark:bg-slate-800"></div>
                                {/* Main card with image */}
                                <img
                                  src="/images/house-exterior.jpg"
                                  alt={playlist.title}
                                  className="relative z-10 h-full w-full rounded-md object-cover p-0 shadow-md transition-all duration-300 hover:shadow-lg"
                                />
                              </div>
                              {/* Text below the stacked cards */}
                              <div className="mt-4">
                                <h3 className="line-clamp-1 text-lg font-semibold text-slate-900 dark:text-slate-100">
                                  {playlist.title}
                                </h3>
                                <p className="text-sm text-slate-600 dark:text-slate-400">{playlist.count} messages</p>
                              </div>
                            </CarouselItem>
                          ))}
                        </CarouselContent>
                        <CarouselPrevious className="translate-x-8" />
                        <CarouselNext className="-translate-x-8" />
                      </Carousel>
                    </CardContent>
                  </Card>

                  {/* Categories of Messages */}
                  <Card className="mt-8 bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-r from-primary/80 to-primary/70">
                          <Tag className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <h2 className="text-xl font-semibold">Message Categories</h2>
                          <p className="text-sm text-slate-600 dark:text-slate-400">Explore by topic</p>
                        </div>
                      </div>
                      <Link
                        to="/categories"
                        className="flex items-center gap-1 text-sm font-medium text-primary hover:underline"
                      >
                        See All <ArrowRight className="h-4 w-4" />
                      </Link>
                    </CardHeader>
                    <CardContent className="p-6 pt-0">
                      <Carousel className="w-full">
                        <CarouselContent className="-ml-4">
                          {categories.map((category) => (
                            <CarouselItem key={category.id} className="basis-1/2 pl-4 md:basis-1/3 lg:basis-1/5">
                              <Card className="h-full rounded-lg shadow-md transition-all duration-300 hover:shadow-lg">
                                <CardContent className="flex flex-col items-center justify-center gap-2 p-4 text-center">
                                  <div className="mb-2 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-violet-50 to-purple-50 shadow-md dark:from-violet-900/30 dark:to-purple-900/30">
                                    {category.icon}
                                  </div>
                                  <h3 className="font-semibold text-slate-900 dark:text-slate-100">{category.name}</h3>
                                </CardContent>
                              </Card>
                            </CarouselItem>
                          ))}
                        </CarouselContent>
                        <CarouselPrevious className="translate-x-8" />
                        <CarouselNext className="-translate-x-8" />
                      </Carousel>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Comments Tab - DEFAULT for desktop */}
                <TabsContent value="comments" className="mt-8 space-y-6">
                  <div className="mb-6 flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-r from-primary/80 to-primary/70">
                      <MessageCircle className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h2 className="text-xl font-semibold">Live Comments</h2>
                      <p className="text-sm text-slate-600 dark:text-slate-400">Join the conversation</p>
                    </div>
                  </div>

                  {/* Comment Form */}
                  <Card className="border-0 bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70">
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        <Textarea
                          placeholder="Share your thoughts, prayer requests, or testimonies..."
                          value={commentText}
                          onChange={(e) => setCommentText(e.target.value)}
                          className="min-h-[100px] resize-none rounded-xl border-0 bg-slate-50/50 focus:ring-2 focus:ring-violet-500 dark:bg-slate-900/50"
                        />
                        <Button
                          onClick={handleSubmitComment}
                          className="w-full rounded-lg bg-gradient-to-r from-primary to-primary hover:from-primary hover:to-primary/80"
                          disabled={!commentText.trim() || isPostingComment}
                        >
                          {isPostingComment ? (
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          ) : (
                            <Send className="mr-2 h-4 w-4" />
                          )}
                          {isPostingComment ? "Posting..." : "Post Comment"}
                        </Button>
                        {commentPostError && <p className="text-sm text-red-500">{commentPostError}</p>}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Comments List */}
                  <Card className="border-0 bg-white shadow-lg backdrop-blur-sm dark:bg-slate-800/70">
                    <CardContent className="p-6">
                      <ScrollArea className="h-96">
                        <div className="space-y-4">
                          {comments.map((comment) => (
                            <motion.div
                              key={comment.id}
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              className="flex gap-3 p-4 bg-slate-50/50 rounded-lg dark:bg-slate-900/50"
                            >
                              <Avatar className="h-10 w-10">
                                <AvatarFallback>{comment.avatar}</AvatarFallback>
                              </Avatar>
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="font-semibold text-sm">{comment.name}</span>
                                  <span className="text-xs text-muted-foreground">{comment.time}</span>
                                </div>
                                <p className="text-sm">{comment.text}</p>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Comments Tab - DEFAULT for desktop */}
                <TabsContent value="give" className="mt-8 space-y-6">
                  <div className="mb-6 flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-r from-primary/80 to-primary/70">
                      <Gift className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h2 className="text-xl font-semibold">Give</h2>
                      {/* <p className="text-sm text-slate-600 dark:text-slate-400">Join the conversation</p> */}
                    </div>
                  </div>

                  {/* Give with Joy section */}
                  <Card className="mt-8 border-violet-200/50 bg-gradient-to-br from-violet-50 to-purple-50 shadow-lg dark:border-violet-800/50 dark:from-violet-900/20 dark:to-purple-900/20">
                    <CardContent className="p-8 text-center">
                      <div className="mb-6">
                        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r from-primary/80 to-primary/70">
                          <Heart className="h-8 w-8 text-white" />
                        </div>
                        <h3 className="mb-3 text-2xl font-bold">Give with Joy</h3>
                        <p className="mb-6 leading-relaxed text-slate-600 dark:text-slate-400">
                          "Give, and it will be given to you. A good measure, pressed down, shaken together and running
                          over, will be poured into your lap." - Luke 6:38
                        </p>
                      </div>
                      <div className="flex flex-col items-center rounded-xl bg-white p-6 backdrop-blur-sm dark:bg-slate-800/70">
                        <p className="mb-4 text-lg">
                          To Give, Kindly text the word <span className="font-bold text-primary/80">GIVE</span> to
                        </p>
                        <div className="flex items-center gap-2">
                          <div className="flex items-center justify-center gap-2 rounded-xl border border-primary/30 px-8 py-3 text-lg">
                            <MessageCircle className="h-5 w-5" />
                            +234 704 206 6472
                          </div>
                          <Copy
                            className="h-4 w-4 cursor-pointer text-gray-400 transition hover:text-gray-600"
                            onClick={() => navigator.clipboard.writeText("+234 704 206 6472")}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Quick Links Tab */}
                <TabsContent value="links" className="mt-8 space-y-6">
                  <div className="mb-6 flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-r from-primary/80 to-primary/70">
                      <ExternalLink className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h2 className="text-xl font-semibold">Quick Links</h2>
                    </div>
                  </div>
                  <div className="grid gap-3">
                    {[
                      "Join the Impact Bayelsa Online Prayer Rally",
                      "Join the Pastor Chris Live Prayer Network",
                      "Rhapsody of Realities (Read and Earn)",
                      "Reachout World with Rhapsody Of Realities",
                      "Healing School",
                      "Healing Streams TV",
                      "Listen to exciting Messages by Pastor Chris",
                      "Unending Praise 24/7",
                    ].map((link, index) => (
                      <Card
                        key={index}
                        className="group cursor-pointer border-0 bg-gray-100 backdrop-blur-sm transition-all duration-200 hover:shadow-xl dark:bg-slate-800/70"
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-slate-900 transition-colors group-hover:text-primary/70 dark:text-slate-100">
                              {link}
                            </span>
                            <ExternalLink className="h-4 w-4 text-slate-400 transition-colors group-hover:text-primary/80" />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </div>

      {/* MOBILE VERSION - Show home content with compact player */}
      <div className="block lg:hidden min-h-screen bg-gradient-to-br from-slate-100 via-white to-violet-50/30 dark:from-slate-900 dark:via-slate-800 dark:to-violet-900/10">
        {/* Main Content - Home content by default */}
        <div className="px-4 py-6 pb-16">
          {/* Extra bottom padding for compact player */}

          {/* Hero Section */}
          <div className="relative h-48 w-full overflow-hidden rounded-xl bg-slate-900 shadow-lg mb-6">
            <img
              src="/images/house-exterior.jpg"
              alt="Hero Background"
              className="absolute inset-0 h-full w-full object-cover opacity-50"
            />
            <div className="absolute bottom-0 left-0 right-0 h-full bg-gradient-to-b from-transparent to-slate-800"></div>
            <div className="relative z-10 flex h-full flex-col justify-end p-4">
              <h2 className="mb-2 text-lg font-semibold text-white">Healing Streams live with Pastor Chris</h2>
              <p className="text-sm text-white/85">Experience divine healing and miracles</p>
            </div>
          </div>

          {/* Marquee Announcement */}
          <div className="mb-6 overflow-hidden rounded-lg bg-gradient-to-r from-violet-50 to-purple-50 p-3 text-sm text-slate-800 shadow-lg dark:from-violet-900/20 dark:to-purple-900/20 dark:text-slate-200">
            <Marquee gradient={false} speed={30} pauseOnHover>
              <div className="flex items-center gap-6 whitespace-nowrap">{marqueeContent()}</div>
            </Marquee>
          </div>

          {/* Upcoming Programs */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Upcoming Programs</h2>
              <Link to="/upcoming-programs" className="text-sm text-primary hover:underline">
                See More
              </Link>
            </div>
            <Carousel className="w-full">
              <CarouselContent className="-ml-4">
                {upcomingPrograms.slice(0, 4).map((program) => (
                  <CarouselItem key={program.id} className="basis-1/2 pl-4 md:basis-1/3 lg:basis-1/4">
                    <Card className="gap-0 overflow-hidden p-0">
                      <img
                        src="/images/house-exterior.jpg"
                        alt={program.title}
                        className="h-20 w-full object-cover"
                      />
                      <CardContent className="p-3">
                        <h3 className="text-sm font-semibold line-clamp-1">{program.title}</h3>
                        <p className="text-xs text-muted-foreground mt-1">{program.date}</p>
                      </CardContent>
                    </Card>
                  </CarouselItem>
                ))}
              </CarouselContent>
            </Carousel>
          </div>

          {/* Messages */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Latest Messages</h2>
              <Link to="/messages" className="text-sm text-primary hover:underline">
                See More
              </Link>
            </div>
            <div className="space-y-3">
              {messages.slice(0, 3).map((message) => (
                <Card key={message.id} className="p-3">
                  <div className="flex gap-3">
                    <img
                      src="/images/house-exterior.jpg"
                      alt={message.title}
                      className="h-16 w-16 rounded-lg object-cover"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold text-sm line-clamp-2">{message.title}</h3>
                      <p className="text-xs text-muted-foreground mt-1">{message.speaker}</p>
                      <p className="text-xs text-muted-foreground">{message.duration}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* Podcasts */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Featured Podcasts</h2>
              <Link to="/podcasts" className="text-sm text-primary hover:underline">
                View All
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {podcasts.slice(0, 4).map((podcast) => (
                <Card key={podcast.id} className="p-3 gap-0">
                  <img
                    src="/images/house-exterior.jpg"
                    alt={podcast.title}
                    className="h-20 w-full rounded-lg object-cover mb-2"
                  />
                  <h3 className="font-semibold text-sm line-clamp-1">{podcast.title}</h3>
                  <p className="text-xs text-muted-foreground">{podcast.host}</p>
                  <div className="flex items-center gap-1 mt-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        size={12}
                        className={`${i < podcast.rating ? "fill-yellow-500 text-yellow-500" : "text-gray-300"}`}
                      />
                    ))}
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>

        {/* Mobile Compact Player Component */}
        <MobileCompactPlayer />
      </div>
    </>
  )
}
