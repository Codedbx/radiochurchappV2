"use client"
import { useState } from "react"
import { Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Skeleton } from "@/components/ui/skeleton"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Heart, Play, Clock, Download, Mic, BookOpen, ListMusic, Trash2, Share2 } from "lucide-react"
import { useFavorites, useRemoveFromFavorites } from "../hooks/useFavorites"
import { toast } from "sonner"

export default function FavouritesPage() {
  const [sortBy, setSortBy] = useState("recent")
  const [activeTab, setActiveTab] = useState("all")

  const { data: allFavorites, isLoading: allLoading } = useFavorites("all")
  const { data: messageFavorites, isLoading: messagesLoading } = useFavorites("message")
  const { data: podcastFavorites, isLoading: podcastsLoading } = useFavorites("podcast")
  const { data: playlistFavorites, isLoading: playlistsLoading } = useFavorites("playlist")

  const removeFromFavorites = useRemoveFromFavorites()

  const handleRemoveFavorite = (type, id, title) => {
    removeFromFavorites.mutate(
      { type, id },
      {
        onSuccess: () => {
          toast.success(`Removed "${title}" from favorites`)
        },
        onError: () => {
          toast.error("Failed to remove from favorites")
        },
      },
    )
  }

  const handleShare = (item, type) => {
    const url = `${window.location.origin}/${type}s/${item.id}`
    if (navigator.share) {
      navigator.share({
        title: item.title,
        text: item.description || `Check out this ${type}`,
        url: url,
      })
    } else {
      navigator.clipboard.writeText(url)
      toast.success("Link copied to clipboard!")
    }
  }

  const sortItems = (items) => {
    if (!items) return []

    switch (sortBy) {
      case "recent":
        return [...items].sort((a, b) => new Date(b.favorited_at) - new Date(a.favorited_at))
      case "oldest":
        return [...items].sort((a, b) => new Date(a.favorited_at) - new Date(b.favorited_at))
      case "title":
        return [...items].sort((a, b) => a.title.localeCompare(b.title))
      default:
        return items
    }
  }

  const renderMessageCard = (message) => (
    <Card key={message.id} className="group overflow-hidden hover:shadow-lg transition-all duration-300">
      <div className="relative">
        <img
          src={message.image_url || "/placeholder.svg?height=200&width=300"}
          alt={message.title}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <Button size="sm" className="bg-white/20 backdrop-blur-sm hover:bg-white/30">
            <Play className="h-4 w-4 mr-2" />
            Play
          </Button>
        </div>
        <div className="absolute top-2 right-2 flex gap-1">
          <Button
            size="sm"
            variant="ghost"
            className="bg-black/20 backdrop-blur-sm hover:bg-black/40 text-white"
            onClick={() => handleShare(message, "message")}
          >
            <Share2 className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="bg-black/20 backdrop-blur-sm hover:bg-red-500 text-white"
            onClick={() => handleRemoveFavorite("message", message.id, message.title)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
      <CardContent className="p-4">
        <Link to={`/messages/${message.id}`}>
          <h3 className="font-semibold line-clamp-2 group-hover:text-primary transition-colors">{message.title}</h3>
        </Link>
        <p className="text-sm text-muted-foreground mt-1">{message.speaker}</p>
        <div className="flex items-center justify-between mt-3">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Clock className="h-3 w-3" />
            {message.duration}
          </div>
          <Badge variant="secondary" className="text-xs">
            {message.category?.name}
          </Badge>
        </div>
        <div className="flex items-center justify-between mt-3">
          <span className="text-xs text-muted-foreground">
            Added {new Date(message.favorited_at).toLocaleDateString()}
          </span>
          {message.allow_download && (
            <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
              <Download className="h-3 w-3" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  )

  const renderPodcastCard = (podcast) => (
    <Card key={podcast.id} className="group overflow-hidden hover:shadow-lg transition-all duration-300">
      <div className="relative">
        <img
          src={podcast.image_url || "/placeholder.svg?height=200&width=300"}
          alt={podcast.title}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-2 left-2">
          <Badge className="bg-black/20 backdrop-blur-sm text-white border-white/30">
            <Mic className="h-3 w-3 mr-1" />
            Podcast
          </Badge>
        </div>
        <div className="absolute top-2 right-2 flex gap-1">
          <Button
            size="sm"
            variant="ghost"
            className="bg-black/20 backdrop-blur-sm hover:bg-black/40 text-white"
            onClick={() => handleShare(podcast, "podcast")}
          >
            <Share2 className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="bg-black/20 backdrop-blur-sm hover:bg-red-500 text-white"
            onClick={() => handleRemoveFavorite("podcast", podcast.id, podcast.title)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
      <CardContent className="p-4">
        <Link to={`/podcasts/${podcast.id}`}>
          <h3 className="font-semibold line-clamp-2 group-hover:text-primary transition-colors">{podcast.title}</h3>
        </Link>
        <p className="text-sm text-muted-foreground mt-1">{podcast.host}</p>
        <div className="flex items-center justify-between mt-3">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Clock className="h-3 w-3" />
            {podcast.episodes_count} episodes
          </div>
          <Badge variant="secondary" className="text-xs">
            {podcast.category?.name}
          </Badge>
        </div>
        <div className="flex items-center justify-between mt-3">
          <span className="text-xs text-muted-foreground">
            Added {new Date(podcast.favorited_at).toLocaleDateString()}
          </span>
        </div>
      </CardContent>
    </Card>
  )

  const renderPlaylistCard = (playlist) => (
    <Card key={playlist.id} className="group overflow-hidden hover:shadow-lg transition-all duration-300">
      <div className="relative h-32 w-full">
        {/* Stacked background cards */}
        <div className="absolute inset-x-0 top-0 h-full translate-x-6 translate-y-2 transform rounded-md bg-slate-300 shadow-lg dark:bg-slate-700"></div>
        <div className="absolute inset-x-0 top-0 h-full translate-x-3 translate-y-1 transform rounded-md bg-slate-400 shadow-lg dark:bg-slate-800"></div>
        {/* Main card with image */}
        <img
          src={playlist.image_url || "/placeholder.svg?height=200&width=300"}
          alt={playlist.title}
          className="relative z-10 h-full w-full rounded-md object-cover shadow-md"
        />
        <div className="absolute top-2 right-2 z-20 flex gap-1">
          <Button
            size="sm"
            variant="ghost"
            className="bg-black/20 backdrop-blur-sm hover:bg-black/40 text-white"
            onClick={() => handleShare(playlist, "playlist")}
          >
            <Share2 className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="bg-black/20 backdrop-blur-sm hover:bg-red-500 text-white"
            onClick={() => handleRemoveFavorite("playlist", playlist.id, playlist.title)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
      <CardContent className="p-4">
        <Link to={`/playlists/${playlist.id}`}>
          <h3 className="font-semibold line-clamp-2 group-hover:text-primary transition-colors">{playlist.title}</h3>
        </Link>
        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{playlist.description}</p>
        <div className="flex items-center justify-between mt-3">
          <span className="text-xs text-muted-foreground">{playlist.count} items</span>
          <Badge variant="secondary" className="text-xs">
            <ListMusic className="h-3 w-3 mr-1" />
            Playlist
          </Badge>
        </div>
        <div className="flex items-center justify-between mt-3">
          <span className="text-xs text-muted-foreground">
            Added {new Date(playlist.favorited_at).toLocaleDateString()}
          </span>
        </div>
      </CardContent>
    </Card>
  )

  const isLoading = allLoading || messagesLoading || podcastsLoading || playlistsLoading

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
            <Heart className="h-8 w-8 text-red-500" />
            My Favorites
          </h1>
          <p className="text-muted-foreground">Your saved messages, podcasts, and playlists</p>
        </div>

        {/* Sort Options */}
        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="recent">Recently Added</SelectItem>
            <SelectItem value="oldest">Oldest First</SelectItem>
            <SelectItem value="title">Title A-Z</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="space-y-6">
          <div className="flex space-x-1">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-10 w-24" />
            ))}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <Card key={i}>
                <Skeleton className="h-48 w-full" />
                <CardContent className="p-4">
                  <Skeleton className="h-4 w-3/4 mb-2" />
                  <Skeleton className="h-3 w-1/2 mb-2" />
                  <Skeleton className="h-3 w-1/4" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      ) : (
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto">
            <TabsTrigger value="all">All ({allFavorites?.length || 0})</TabsTrigger>
            <TabsTrigger value="messages">
              <BookOpen className="h-4 w-4 mr-2" />
              Messages ({messageFavorites?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="podcasts">
              <Mic className="h-4 w-4 mr-2" />
              Podcasts ({podcastFavorites?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="playlists">
              <ListMusic className="h-4 w-4 mr-2" />
              Playlists ({playlistFavorites?.length || 0})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-8">
            {allFavorites && allFavorites.length > 0 ? (
              <>
                {/* Messages Section */}
                {messageFavorites && messageFavorites.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-xl font-semibold flex items-center gap-2">
                        <BookOpen className="h-5 w-5" />
                        Messages ({messageFavorites.length})
                      </h2>
                      <Link to="/favourites?tab=messages">
                        <Button variant="outline" size="sm">
                          View All
                        </Button>
                      </Link>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                      {sortItems(messageFavorites).slice(0, 4).map(renderMessageCard)}
                    </div>
                  </div>
                )}

                {/* Podcasts Section */}
                {podcastFavorites && podcastFavorites.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-xl font-semibold flex items-center gap-2">
                        <Mic className="h-5 w-5" />
                        Podcasts ({podcastFavorites.length})
                      </h2>
                      <Link to="/favourites?tab=podcasts">
                        <Button variant="outline" size="sm">
                          View All
                        </Button>
                      </Link>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                      {sortItems(podcastFavorites).slice(0, 4).map(renderPodcastCard)}
                    </div>
                  </div>
                )}

                {/* Playlists Section */}
                {playlistFavorites && playlistFavorites.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-xl font-semibold flex items-center gap-2">
                        <ListMusic className="h-5 w-5" />
                        Playlists ({playlistFavorites.length})
                      </h2>
                      <Link to="/favourites?tab=playlists">
                        <Button variant="outline" size="sm">
                          View All
                        </Button>
                      </Link>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                      {sortItems(playlistFavorites).slice(0, 4).map(renderPlaylistCard)}
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-12">
                <Heart className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                <h3 className="text-lg font-semibold mb-2">No favorites yet</h3>
                <p className="text-muted-foreground mb-6">
                  Start adding messages, podcasts, and playlists to your favorites
                </p>
                <div className="flex gap-4 justify-center">
                  <Link to="/messages">
                    <Button>Browse Messages</Button>
                  </Link>
                  <Link to="/podcasts">
                    <Button variant="outline">Browse Podcasts</Button>
                  </Link>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="messages">
            {messageFavorites && messageFavorites.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {sortItems(messageFavorites).map(renderMessageCard)}
              </div>
            ) : (
              <div className="text-center py-12">
                <BookOpen className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                <h3 className="text-lg font-semibold mb-2">No favorite messages</h3>
                <p className="text-muted-foreground mb-6">Save messages you love to access them quickly later</p>
                <Link to="/messages">
                  <Button>Browse Messages</Button>
                </Link>
              </div>
            )}
          </TabsContent>

          <TabsContent value="podcasts">
            {podcastFavorites && podcastFavorites.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {sortItems(podcastFavorites).map(renderPodcastCard)}
              </div>
            ) : (
              <div className="text-center py-12">
                <Mic className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                <h3 className="text-lg font-semibold mb-2">No favorite podcasts</h3>
                <p className="text-muted-foreground mb-6">Save podcasts you enjoy to find them easily</p>
                <Link to="/podcasts">
                  <Button>Browse Podcasts</Button>
                </Link>
              </div>
            )}
          </TabsContent>

          <TabsContent value="playlists">
            {playlistFavorites && playlistFavorites.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {sortItems(playlistFavorites).map(renderPlaylistCard)}
              </div>
            ) : (
              <div className="text-center py-12">
                <ListMusic className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                <h3 className="text-lg font-semibold mb-2">No favorite playlists</h3>
                <p className="text-muted-foreground mb-6">Save playlists to build your personal collection</p>
                <Link to="/playlists">
                  <Button>Browse Playlists</Button>
                </Link>
              </div>
            )}
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}
