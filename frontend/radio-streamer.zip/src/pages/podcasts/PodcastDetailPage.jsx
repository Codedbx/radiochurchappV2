"use client"
import { useState, useRef, useEffect } from "react"
import { useParams, Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Skeleton } from "@/components/ui/skeleton"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Heart,
  Download,
  Share2,
  Clock,
  Eye,
  MessageCircle,
  Send,
  ArrowLeft,
  Loader2,
  Star,
  Mic,
  Bell,
  BellOff,
} from "lucide-react"
import {
  usePodcast,
  useSubscribeToPodcast,
  useUnsubscribeFromPodcast,
  useAddPodcastComment,
} from "../../hooks/usePodcasts"
import { useToggleFavorite } from "../../hooks/useFavorites"
import { toast } from "sonner"

export default function PodcastDetailPage() {
  const { id } = useParams()
  const audioRef = useRef(null)

  // Audio player state
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [volume, setVolume] = useState(80)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [isLoading, setIsLoading] = useState(false)
  const [currentEpisode, setCurrentEpisode] = useState(null)

  // Comment state
  const [commentText, setCommentText] = useState("")

  // API hooks
  const { data: podcast, isLoading: podcastLoading, error } = usePodcast(id)
  const subscribeToPodcast = useSubscribeToPodcast()
  const unsubscribeFromPodcast = useUnsubscribeFromPodcast()
  const addComment = useAddPodcastComment()
  const toggleFavorite = useToggleFavorite()

  // Set first episode as current when podcast loads
  useEffect(() => {
    if (podcast?.episodes?.length > 0 && !currentEpisode) {
      setCurrentEpisode(podcast.episodes[0])
    }
  }, [podcast, currentEpisode])

  // Audio event handlers
  useEffect(() => {
    const audio = audioRef.current
    if (!audio || !currentEpisode) return

    const handleLoadedMetadata = () => {
      setDuration(audio.duration)
      setIsLoading(false)
    }

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime)
    }

    const handleWaiting = () => setIsLoading(true)
    const handleCanPlay = () => setIsLoading(false)

    audio.addEventListener("loadedmetadata", handleLoadedMetadata)
    audio.addEventListener("timeupdate", handleTimeUpdate)
    audio.addEventListener("waiting", handleWaiting)
    audio.addEventListener("canplay", handleCanPlay)

    return () => {
      audio.removeEventListener("loadedmetadata", handleLoadedMetadata)
      audio.removeEventListener("timeupdate", handleTimeUpdate)
      audio.removeEventListener("waiting", handleWaiting)
      audio.removeEventListener("canplay", handleCanPlay)
    }
  }, [currentEpisode])

  const togglePlayPause = () => {
    const audio = audioRef.current
    if (!audio || !currentEpisode) return

    if (isPlaying) {
      audio.pause()
    } else {
      setIsLoading(true)
      audio.play().catch((error) => {
        console.error("Error playing audio:", error)
        toast.error("Failed to play audio")
        setIsLoading(false)
      })
    }
    setIsPlaying(!isPlaying)
  }

  const toggleMute = () => {
    const audio = audioRef.current
    if (!audio) return

    audio.muted = !isMuted
    setIsMuted(!isMuted)
  }

  const handleVolumeChange = (newVolume) => {
    const audio = audioRef.current
    if (!audio) return

    audio.volume = newVolume / 100
    setVolume(newVolume)
  }

  const handleSeek = (e) => {
    const audio = audioRef.current
    if (!audio || !duration) return

    const rect = e.currentTarget.getBoundingClientRect()
    const percent = (e.clientX - rect.left) / rect.width
    const newTime = percent * duration

    audio.currentTime = newTime
    setCurrentTime(newTime)
  }

  const formatTime = (time) => {
    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60)
    return `${minutes}:${seconds.toString().padStart(2, "0")}`
  }

  const handleSubscribe = () => {
    if (podcast.is_subscribed) {
      unsubscribeFromPodcast.mutate({ podcastId: id })
    } else {
      subscribeToPodcast.mutate({ podcastId: id })
    }
  }

  const handleAddComment = async () => {
    if (!commentText.trim() || !currentEpisode) return

    try {
      await addComment.mutateAsync({
        episodeId: currentEpisode.id,
        commentData: { body: commentText },
      })
      setCommentText("")
    } catch (error) {
      toast.error("Failed to add comment")
    }
  }

  const handleToggleFavorite = () => {
    toggleFavorite.mutate({
      type: "podcast",
      id: id,
      isFavorited: podcast.is_favorited,
    })
  }

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: podcast?.title,
        text: podcast?.description,
        url: window.location.href,
      })
    } else {
      navigator.clipboard.writeText(window.location.href)
      toast.success("Link copied to clipboard!")
    }
  }

  const handleDownload = () => {
    if (currentEpisode?.audio_url) {
      const link = document.createElement("a")
      link.href = currentEpisode.audio_url
      link.download = `${currentEpisode.title}.mp3`
      link.click()
    }
  }

  const selectEpisode = (episode) => {
    setCurrentEpisode(episode)
    setIsPlaying(false)
    setCurrentTime(0)
    setDuration(0)
  }

  if (podcastLoading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <Skeleton className="h-8 w-32 mb-6" />
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <Skeleton className="h-64 w-full rounded-lg" />
            <Skeleton className="h-8 w-3/4" />
            <Skeleton className="h-20 w-full" />
          </div>
          <div className="space-y-4">
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-48 w-full" />
          </div>
        </div>
      </div>
    )
  }

  if (error || !podcast) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <p className="text-red-500 mb-4">Podcast not found or failed to load.</p>
        <Link to="/podcasts">
          <Button>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Podcasts
          </Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Back Button */}
      <Link to="/podcasts" className="inline-flex items-center text-sm text-muted-foreground hover:text-primary mb-6">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Podcasts
      </Link>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Podcast Header */}
          <Card className="overflow-hidden">
            <div className="relative">
              <img
                src={podcast.image_url || "/placeholder.svg?height=300&width=600"}
                alt={podcast.title}
                className="w-full h-64 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-4 left-4 right-4">
                <div className="flex items-center gap-4 mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge className="bg-white/20 backdrop-blur-sm text-white border-white/30">
                        <Mic className="h-3 w-3 mr-1" />
                        Podcast
                      </Badge>
                      <div className="flex items-center gap-1">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            size={16}
                            className={`${
                              i < (podcast.rating || 0) ? "fill-yellow-500 text-yellow-500" : "text-white/50"
                            }`}
                          />
                        ))}
                        <span className="text-white/80 text-sm ml-1">({podcast.rating || 0})</span>
                      </div>
                    </div>
                    <h1 className="text-2xl font-bold text-white mb-1">{podcast.title}</h1>
                    <p className="text-white/80">Hosted by {podcast.host}</p>
                  </div>
                  <Button
                    onClick={handleSubscribe}
                    disabled={subscribeToPodcast.isPending || unsubscribeFromPodcast.isPending}
                    className="bg-white/20 backdrop-blur-sm hover:bg-white/30 text-white border-white/30"
                  >
                    {podcast.is_subscribed ? (
                      <>
                        <BellOff className="mr-2 h-4 w-4" />
                        Unsubscribe
                      </>
                    ) : (
                      <>
                        <Bell className="mr-2 h-4 w-4" />
                        Subscribe
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </Card>

          {/* Current Episode Player */}
          {currentEpisode && (
            <Card className="overflow-hidden">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Play className="h-5 w-5" />
                  Now Playing: {currentEpisode.title}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Audio Controls */}
                <div className="flex items-center gap-4">
                  <Button size="lg" onClick={togglePlayPause} className="bg-gradient-to-r from-primary to-primary/80">
                    {isLoading ? (
                      <Loader2 className="h-6 w-6 animate-spin" />
                    ) : isPlaying ? (
                      <Pause className="h-6 w-6" />
                    ) : (
                      <Play className="h-6 w-6 ml-1" />
                    )}
                  </Button>
                  <div className="flex-1">
                    <p className="font-medium line-clamp-1">{currentEpisode.title}</p>
                    <p className="text-sm text-muted-foreground">{currentEpisode.description}</p>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="space-y-2">
                  <div className="w-full h-2 bg-muted rounded-full cursor-pointer" onClick={handleSeek}>
                    <div
                      className="h-full bg-primary rounded-full transition-all duration-300"
                      style={{ width: `${duration ? (currentTime / duration) * 100 : 0}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{formatTime(currentTime)}</span>
                    <span>{formatTime(duration)}</span>
                  </div>
                </div>

                {/* Volume and Actions */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Button variant="ghost" size="sm" onClick={toggleMute}>
                      {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                    </Button>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">Volume</span>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={volume}
                        onChange={(e) => handleVolumeChange(Number.parseInt(e.target.value))}
                        className="w-20"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" onClick={handleToggleFavorite}>
                      <Heart className={`h-4 w-4 ${podcast.is_favorited ? "fill-red-500 text-red-500" : ""}`} />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={handleShare}>
                      <Share2 className="h-4 w-4" />
                    </Button>
                    {currentEpisode.allow_download && (
                      <Button variant="ghost" size="sm" onClick={handleDownload}>
                        <Download className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Podcast Details */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <Badge variant="secondary">{podcast.category?.name}</Badge>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Eye className="h-4 w-4" />
                    {podcast.listens} listens
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    {podcast.episodes?.length || 0} episodes
                  </div>
                  <div className="flex items-center gap-1">
                    <MessageCircle className="h-4 w-4" />
                    {podcast.comments?.length || 0} comments
                  </div>
                </div>
              </div>

              <div className="prose prose-sm max-w-none">
                <p className="text-muted-foreground leading-relaxed">{podcast.description}</p>
              </div>
            </CardContent>
          </Card>

          {/* Episodes and Comments Tabs */}
          <Tabs defaultValue="episodes" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="episodes">Episodes ({podcast.episodes?.length || 0})</TabsTrigger>
              <TabsTrigger value="comments">Comments ({podcast.comments?.length || 0})</TabsTrigger>
            </TabsList>

            <TabsContent value="episodes" className="space-y-4">
              <div className="space-y-3">
                {podcast.episodes?.map((episode, index) => (
                  <Card
                    key={episode.id}
                    className={`cursor-pointer transition-all duration-200 hover:shadow-md ${
                      currentEpisode?.id === episode.id ? "ring-2 ring-primary" : ""
                    }`}
                    onClick={() => selectEpisode(episode)}
                  >
                    <CardContent className="p-4">
                      <div className="flex gap-4">
                        <div className="flex-shrink-0 w-12 h-12 bg-muted rounded-lg flex items-center justify-center">
                          <span className="font-semibold text-sm">{index + 1}</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium line-clamp-2">{episode.title}</h4>
                          <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{episode.description}</p>
                          <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {episode.duration}
                            </div>
                            <span>{new Date(episode.created_at).toLocaleDateString()}</span>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation()
                            selectEpisode(episode)
                            togglePlayPause()
                          }}
                        >
                          {currentEpisode?.id === episode.id && isPlaying ? (
                            <Pause className="h-4 w-4" />
                          ) : (
                            <Play className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="comments" className="space-y-6">
              {/* Add Comment */}
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <Textarea
                      placeholder="Share your thoughts about this podcast..."
                      value={commentText}
                      onChange={(e) => setCommentText(e.target.value)}
                      className="min-h-[100px]"
                    />
                    <Button
                      onClick={handleAddComment}
                      disabled={!commentText.trim() || addComment.isPending}
                      className="w-full sm:w-auto"
                    >
                      {addComment.isPending ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        <Send className="mr-2 h-4 w-4" />
                      )}
                      Post Comment
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Comments List */}
              <Card>
                <CardContent className="p-6">
                  <ScrollArea className="h-96">
                    <div className="space-y-4">
                      {podcast.comments?.map((comment) => (
                        <div key={comment.id} className="flex gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={comment.user?.avatar || "/placeholder.svg"} />
                            <AvatarFallback>
                              {comment.user?.name?.charAt(0) || comment.author_name?.charAt(0) || "A"}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-sm">
                                {comment.user?.name || comment.author_name || "Anonymous"}
                              </span>
                              <span className="text-xs text-muted-foreground">
                                {new Date(comment.created_at).toLocaleDateString()}
                              </span>
                            </div>
                            <p className="text-sm text-muted-foreground">{comment.body}</p>
                          </div>
                        </div>
                      ))}

                      {(!podcast.comments || podcast.comments.length === 0) && (
                        <div className="text-center py-8 text-muted-foreground">
                          <MessageCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                          <p>No comments yet. Be the first to share your thoughts!</p>
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Podcast Stats */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Statistics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Total Listens</span>
                <span className="font-medium">{podcast.listens}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Episodes</span>
                <span className="font-medium">{podcast.episodes?.length || 0}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Subscribers</span>
                <span className="font-medium">{podcast.subscribers_count || 0}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Rating</span>
                <div className="flex items-center gap-1">
                  <Star size={14} className="fill-yellow-500 text-yellow-500" />
                  <span className="font-medium">{podcast.rating || 0}</span>
                </div>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Created</span>
                <span className="font-medium">{new Date(podcast.created_at).toLocaleDateString()}</span>
              </div>
            </CardContent>
          </Card>

          {/* Related Podcasts */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Related Podcasts</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="flex gap-3">
                  <img
                    src="/placeholder.svg?height=60&width=60"
                    alt="Related podcast"
                    className="w-15 h-15 object-cover rounded-lg"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-sm line-clamp-2">Faith Foundations Podcast</h4>
                    <p className="text-xs text-muted-foreground mt-1">Pastor Sarah</p>
                    <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      12 episodes
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Hidden Audio Element */}
      <audio
        ref={audioRef}
        src={currentEpisode?.audio_url}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onEnded={() => setIsPlaying(false)}
        preload="metadata"
      />
    </div>
  )
}
