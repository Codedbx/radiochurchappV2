"use client"
import { useState } from "react"
import { Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Skeleton } from "@/components/ui/skeleton"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Play, Clock, Heart, Download, Mic, Star, Plus } from "lucide-react"
import { usePodcasts, useSubscribedPodcasts } from "../../hooks/usePodcasts"
import { useToggleFavorite } from "../../hooks/useFavorites"
import { useAuthStore } from "../../store/authStore"

export default function PodcastsPage() {
  const { isAuthenticated } = useAuthStore()
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [sortBy, setSortBy] = useState("latest")
  const [currentPage, setCurrentPage] = useState(1)

  const {
    data: podcastsData,
    isLoading,
    error,
  } = usePodcasts({
    search: searchQuery,
    category: selectedCategory !== "all" ? selectedCategory : undefined,
    sort: sortBy,
    page: currentPage,
    per_page: 12,
  })

  const { data: subscribedPodcasts } = useSubscribedPodcasts()
  const toggleFavorite = useToggleFavorite()

  const podcasts = podcastsData?.data || []
  const pagination = podcastsData?.meta || {}

  const categories = [
    { id: "all", name: "All Categories" },
    { id: "faith", name: "Faith" },
    { id: "healing", name: "Healing" },
    { id: "prosperity", name: "Prosperity" },
    { id: "prayer", name: "Prayer" },
    { id: "youth", name: "Youth" },
  ]

  const handleFavoriteToggle = (podcastId, isFavorited) => {
    toggleFavorite.mutate({
      type: "podcast",
      id: podcastId,
      isFavorited,
    })
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <p className="text-red-500">Failed to load podcasts. Please try again.</p>
          <Button onClick={() => window.location.reload()} className="mt-4">
            Retry
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Podcasts</h1>
          <p className="text-muted-foreground">Discover inspiring podcast series from our community</p>
        </div>
        {isAuthenticated && (
          <Link to="/request-podcast">
            <Button className="bg-gradient-to-r from-primary to-primary/80">
              <Plus className="mr-2 h-4 w-4" />
              Request Upload Rights
            </Button>
          </Link>
        )}
      </div>

      <Tabs defaultValue="all" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 lg:w-auto lg:grid-cols-3">
          <TabsTrigger value="all">All Podcasts</TabsTrigger>
          <TabsTrigger value="subscribed" disabled={!isAuthenticated}>
            My Subscriptions
          </TabsTrigger>
          <TabsTrigger value="featured">Featured</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-6">
          {/* Filters */}
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search podcasts..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Category Filter */}
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full lg:w-48">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Sort */}
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full lg:w-48">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="latest">Latest</SelectItem>
                <SelectItem value="popular">Most Popular</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
                <SelectItem value="title">Title A-Z</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Podcasts Grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {Array.from({ length: 8 }).map((_, i) => (
                <Card key={i} className="overflow-hidden">
                  <Skeleton className="h-48 w-full" />
                  <CardContent className="p-4">
                    <Skeleton className="h-4 w-3/4 mb-2" />
                    <Skeleton className="h-3 w-1/2 mb-2" />
                    <Skeleton className="h-3 w-1/4" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {podcasts.map((podcast) => (
                  <Card key={podcast.id} className="group overflow-hidden hover:shadow-lg transition-all duration-300">
                    <div className="relative">
                      <img
                        src={podcast.image_url || "/placeholder.svg?height=200&width=300"}
                        alt={podcast.title}
                        className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                        <Button size="sm" className="bg-white/20 backdrop-blur-sm hover:bg-white/30">
                          <Play className="h-4 w-4 mr-2" />
                          Listen
                        </Button>
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="absolute top-2 right-2 bg-black/20 backdrop-blur-sm hover:bg-black/40"
                        onClick={(e) => {
                          e.preventDefault()
                          handleFavoriteToggle(podcast.id, podcast.is_favorited)
                        }}
                      >
                        <Heart className={`${podcast.is_favorited ? "fill-red-500 text-red-500" : "text-white"}`} />
                      </Button>
                      <div className="absolute top-2 left-2">
                        <Badge className="bg-black/20 backdrop-blur-sm text-white border-white/30">
                          <Mic className="h-3 w-3 mr-1" />
                          Podcast
                        </Badge>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <Link to={`/podcasts/${podcast.id}`}>
                        <h3 className="font-semibold line-clamp-2 group-hover:text-primary transition-colors">
                          {podcast.title}
                        </h3>
                      </Link>
                      <p className="text-sm text-muted-foreground mt-1">{podcast.host}</p>

                      {/* Rating */}
                      <div className="flex items-center gap-1 mt-2">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            size={14}
                            className={`${i < (podcast.rating || 0) ? "fill-yellow-500 text-yellow-500" : "text-gray-300"}`}
                          />
                        ))}
                        <span className="text-xs text-muted-foreground ml-1">({podcast.rating || 0})</span>
                      </div>

                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {podcast.episodes_count} episodes
                        </div>
                        <Badge variant="secondary" className="text-xs">
                          {podcast.category?.name}
                        </Badge>
                      </div>

                      <div className="flex items-center justify-between mt-3">
                        <span className="text-xs text-muted-foreground">{podcast.listens} listens</span>
                        <div className="flex gap-1">
                          {podcast.allow_download && (
                            <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                              <Download className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Pagination */}
              {pagination.last_page > 1 && (
                <div className="flex justify-center mt-8 gap-2">
                  <Button
                    variant="outline"
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage(currentPage - 1)}
                  >
                    Previous
                  </Button>
                  {Array.from({ length: Math.min(5, pagination.last_page) }, (_, i) => {
                    const page = i + 1
                    return (
                      <Button
                        key={page}
                        variant={currentPage === page ? "default" : "outline"}
                        onClick={() => setCurrentPage(page)}
                      >
                        {page}
                      </Button>
                    )
                  })}
                  <Button
                    variant="outline"
                    disabled={currentPage === pagination.last_page}
                    onClick={() => setCurrentPage(currentPage + 1)}
                  >
                    Next
                  </Button>
                </div>
              )}
            </>
          )}
        </TabsContent>

        <TabsContent value="subscribed" className="space-y-6">
          {subscribedPodcasts?.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {subscribedPodcasts.map((podcast) => (
                <Card key={podcast.id} className="group overflow-hidden hover:shadow-lg transition-all duration-300">
                  <div className="relative">
                    <img
                      src={podcast.image_url || "/placeholder.svg?height=200&width=300"}
                      alt={podcast.title}
                      className="w-full h-48 object-cover"
                    />
                    <div className="absolute top-2 left-2">
                      <Badge className="bg-green-500 text-white">Subscribed</Badge>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <Link to={`/podcasts/${podcast.id}`}>
                      <h3 className="font-semibold line-clamp-2 group-hover:text-primary transition-colors">
                        {podcast.title}
                      </h3>
                    </Link>
                    <p className="text-sm text-muted-foreground mt-1">{podcast.host}</p>
                    <div className="flex items-center justify-between mt-3">
                      <span className="text-xs text-muted-foreground">{podcast.episodes_count} episodes</span>
                      <Badge variant="secondary" className="text-xs">
                        {podcast.category?.name}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Mic className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-50" />
              <h3 className="text-lg font-semibold mb-2">No Subscriptions Yet</h3>
              <p className="text-muted-foreground mb-4">Subscribe to podcasts to see them here</p>
              <Button onClick={() => document.querySelector('[value="all"]').click()}>Browse All Podcasts</Button>
            </div>
          )}
        </TabsContent>

        <TabsContent value="featured" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Featured podcasts would be filtered here */}
            {podcasts
              .filter((p) => p.is_featured)
              .map((podcast) => (
                <Card key={podcast.id} className="group overflow-hidden hover:shadow-lg transition-all duration-300">
                  <div className="relative">
                    <img
                      src={podcast.image_url || "/placeholder.svg?height=200&width=300"}
                      alt={podcast.title}
                      className="w-full h-48 object-cover"
                    />
                    <div className="absolute top-2 left-2">
                      <Badge className="bg-yellow-500 text-white">
                        <Star className="h-3 w-3 mr-1" />
                        Featured
                      </Badge>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <Link to={`/podcasts/${podcast.id}`}>
                      <h3 className="font-semibold line-clamp-2 group-hover:text-primary transition-colors">
                        {podcast.title}
                      </h3>
                    </Link>
                    <p className="text-sm text-muted-foreground mt-1">{podcast.host}</p>
                    <div className="flex items-center justify-between mt-3">
                      <span className="text-xs text-muted-foreground">{podcast.episodes_count} episodes</span>
                      <Badge variant="secondary" className="text-xs">
                        {podcast.category?.name}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
