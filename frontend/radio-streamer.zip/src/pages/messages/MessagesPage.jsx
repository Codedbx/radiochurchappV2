"use client"
import { useState } from "react"
import { Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Skeleton } from "@/components/ui/skeleton"
import { Search, Play, Clock, Heart, Download, Grid, List } from "lucide-react"
import { useMessages } from "../../hooks/useMessages"
import { useToggleFavorite } from "../../hooks/useFavorites"

export default function MessagesPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [sortBy, setSortBy] = useState("latest")
  const [viewMode, setViewMode] = useState("grid")
  const [currentPage, setCurrentPage] = useState(1)

  const {
    data: messagesData,
    isLoading,
    error,
  } = useMessages({
    search: searchQuery,
    category: selectedCategory !== "all" ? selectedCategory : undefined,
    sort: sortBy,
    page: currentPage,
    per_page: 12,
  })

  const toggleFavorite = useToggleFavorite()

  const messages = messagesData?.data || []
  const pagination = messagesData?.meta || {}

  const categories = [
    { id: "all", name: "All Categories" },
    { id: "faith", name: "Faith" },
    { id: "healing", name: "Healing" },
    { id: "prosperity", name: "Prosperity" },
    { id: "prayer", name: "Prayer" },
    { id: "salvation", name: "Salvation" },
  ]

  const handleFavoriteToggle = (messageId, isFavorited) => {
    toggleFavorite.mutate({
      type: "message",
      id: messageId,
      isFavorited,
    })
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <p className="text-red-500">Failed to load messages. Please try again.</p>
          <Button onClick={() => window.location.reload()} className="mt-4">
            Retry
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Messages & Teachings</h1>
        <p className="text-muted-foreground">Grow in faith with powerful messages from our pastors</p>
      </div>

      {/* Filters */}
      <div className="mb-8 space-y-4">
        <div className="flex flex-col lg:flex-row gap-4">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search messages..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Category Filter */}
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-full lg:w-48">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((category) => (
                <SelectItem key={category.id} value={category.id}>
                  {category.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Sort */}
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-full lg:w-48">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="latest">Latest</SelectItem>
              <SelectItem value="oldest">Oldest</SelectItem>
              <SelectItem value="popular">Most Popular</SelectItem>
              <SelectItem value="title">Title A-Z</SelectItem>
            </SelectContent>
          </Select>

          {/* View Mode */}
          <div className="flex border rounded-lg">
            <Button
              variant={viewMode === "grid" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("grid")}
              className="rounded-r-none"
            >
              <Grid className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("list")}
              className="rounded-l-none"
            >
              <List className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Messages Grid/List */}
      {isLoading ? (
        <div
          className={
            viewMode === "grid" ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6" : "space-y-4"
          }
        >
          {Array.from({ length: 8 }).map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <Skeleton className="h-48 w-full" />
              <CardContent className="p-4">
                <Skeleton className="h-4 w-3/4 mb-2" />
                <Skeleton className="h-3 w-1/2 mb-2" />
                <Skeleton className="h-3 w-1/4" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <>
          <div
            className={
              viewMode === "grid" ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6" : "space-y-4"
            }
          >
            {messages.map((message) => (
              <Card key={message.id} className="group overflow-hidden hover:shadow-lg transition-all duration-300">
                {viewMode === "grid" ? (
                  <>
                    <div className="relative">
                      <img
                        src={message.image_url || "/placeholder.svg?height=200&width=300"}
                        alt={message.title}
                        className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                        <Button size="sm" className="bg-white/20 backdrop-blur-sm hover:bg-white/30">
                          <Play className="h-4 w-4 mr-2" />
                          Play
                        </Button>
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="absolute top-2 right-2 bg-black/20 backdrop-blur-sm hover:bg-black/40"
                        onClick={(e) => {
                          e.preventDefault()
                          handleFavoriteToggle(message.id, message.is_favorited)
                        }}
                      >
                        <Heart
                          className={`h-4 w-4 ${message.is_favorited ? "fill-red-500 text-red-500" : "text-white"}`}
                        />
                      </Button>
                    </div>
                    <CardContent className="p-4">
                      <Link to={`/messages/${message.id}`}>
                        <h3 className="font-semibold line-clamp-2 group-hover:text-primary transition-colors">
                          {message.title}
                        </h3>
                      </Link>
                      <p className="text-sm text-muted-foreground mt-1">{message.speaker}</p>
                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {message.duration}
                        </div>
                        <Badge variant="secondary" className="text-xs">
                          {message.category?.name}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between mt-3">
                        <span className="text-xs text-muted-foreground">{message.listens} listens</span>
                        {message.allow_download && (
                          <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                            <Download className="h-3 w-3" />
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </>
                ) : (
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      <img
                        src={message.image_url || "/placeholder.svg?height=80&width=80"}
                        alt={message.title}
                        className="w-20 h-20 object-cover rounded-lg flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <Link to={`/messages/${message.id}`}>
                          <h3 className="font-semibold line-clamp-2 group-hover:text-primary transition-colors">
                            {message.title}
                          </h3>
                        </Link>
                        <p className="text-sm text-muted-foreground mt-1">{message.speaker}</p>
                        <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {message.duration}
                          </div>
                          <span>{message.listens} listens</span>
                          <Badge variant="secondary" className="text-xs">
                            {message.category?.name}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.preventDefault()
                            handleFavoriteToggle(message.id, message.is_favorited)
                          }}
                        >
                          <Heart className={`h-4 w-4 ${message.is_favorited ? "fill-red-500 text-red-500" : ""}`} />
                        </Button>
                        {message.allow_download && (
                          <Button size="sm" variant="ghost">
                            <Download className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>

          {/* Pagination */}
          {pagination.last_page > 1 && (
            <div className="flex justify-center mt-8 gap-2">
              <Button variant="outline" disabled={currentPage === 1} onClick={() => setCurrentPage(currentPage - 1)}>
                Previous
              </Button>
              {Array.from({ length: Math.min(5, pagination.last_page) }, (_, i) => {
                const page = i + 1
                return (
                  <Button
                    key={page}
                    variant={currentPage === page ? "default" : "outline"}
                    onClick={() => setCurrentPage(page)}
                  >
                    {page}
                  </Button>
                )
              })}
              <Button
                variant="outline"
                disabled={currentPage === pagination.last_page}
                onClick={() => setCurrentPage(currentPage + 1)}
              >
                Next
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  )
}
