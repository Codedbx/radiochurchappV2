"use client"
import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Play, Pause, Volume2, VolumeX, Heart, Loader2, ChevronUp, X } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import MobileRadioPlayer from "./MobileRadioPlayer"

export default function MobileCompactPlayer() {
  const audioRef = useRef(null)
  const [isExpanded, setIsExpanded] = useState(false)

  // Audio player states
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [isLiked, setIsLiked] = useState(false)
  const [isLoadingAudio, setIsLoadingAudio] = useState(false)
  const [audioError, setAudioError] = useState(null)

  // Audio control effects
  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const handleCanPlay = () => setIsLoadingAudio(false)
    const handleWaiting = () => setIsLoadingAudio(true)
    const handleError = (e) => {
      console.error("Audio error:", e)
      setAudioError("Failed to load audio. Please try again.")
      setIsLoadingAudio(false)
      setIsPlaying(false)
    }

    audio.addEventListener("canplay", handleCanPlay)
    audio.addEventListener("waiting", handleWaiting)
    audio.addEventListener("error", handleError)

    if (isPlaying) {
      if (audio.paused) {
        setIsLoadingAudio(true)
        audio.play().catch((e) => {
          console.error("Error attempting to play audio:", e)
          setAudioError("Playback failed. Please try clicking play again.")
          setIsLoadingAudio(false)
          setIsPlaying(false)
        })
      }
    } else {
      if (!audio.paused) {
        audio.pause()
      }
    }

    return () => {
      audio.removeEventListener("canplay", handleCanPlay)
      audio.removeEventListener("waiting", handleWaiting)
      audio.removeEventListener("error", handleError)
    }
  }, [isPlaying])

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.muted = isMuted
    }
  }, [isMuted])

  const togglePlayPause = () => {
    setIsPlaying((prev) => !prev)
    setAudioError(null)
  }

  const toggleMute = () => {
    setIsMuted((prev) => !prev)
  }

  const toggleLike = () => {
    setIsLiked((prev) => !prev)
  }

  return (
    <>
      {/* Audio Element */}
      <audio ref={audioRef} preload="auto">
        <source src="https://radio.ifastekpanel.com:1115/stream" type="audio/mpeg" />
        Your browser does not support the audio element.
      </audio>

      {/* Compact Player - Always visible at bottom above mobile nav */}
      <div className="fixed bottom-16 left-0 right-0 z-40 lg:hidden bg-card/95 backdrop-blur-md border-t border-border/50 p-3">
        <div className="flex items-center justify-between cursor-pointer" onClick={() => setIsExpanded(true)}>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary/70 rounded-full flex items-center justify-center">
              <img src="/images/logo.png" alt="logo" className="w-8 h-8 rounded-full" />
            </div>
            <div>
              <h4 className="font-semibold text-sm">Christ Embassy Nigeria</h4>
              <p className="text-xs text-muted-foreground">South South Zone 1</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={(e) => {
                e.stopPropagation()
                toggleLike()
              }}
              className={`h-8 w-8 ${isLiked ? "text-red-500" : "text-muted-foreground"}`}
            >
              <Heart className={`h-4 w-4 ${isLiked ? "fill-red-500" : ""}`} />
            </Button>

            <Button
              onClick={(e) => {
                e.stopPropagation()
                togglePlayPause()
              }}
              className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-primary/80"
            >
              {isLoadingAudio && isPlaying ? (
                <Loader2 className="h-4 w-4 text-white animate-spin" />
              ) : isPlaying ? (
                <Pause className="h-4 w-4 text-white" />
              ) : (
                <Play className="h-4 w-4 text-white ml-0.5" />
              )}
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={(e) => {
                e.stopPropagation()
                toggleMute()
              }}
              className="h-8 w-8 text-muted-foreground"
            >
              {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </Button>

            <ChevronUp size={16} className="text-muted-foreground" />
          </div>
        </div>
      </div>

      {/* Expanded Player - Use existing MobileRadioPlayer */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="fixed inset-0 z-50 lg:hidden"
          >
            <MobileRadioPlayer />
            {/* Close button overlay */}
            <button
              onClick={() => setIsExpanded(false)}
              className="absolute top-4 right-4 z-60 w-8 h-8 bg-black/20 backdrop-blur-sm rounded-full flex items-center justify-center text-white"
            >
              <X size={16} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
