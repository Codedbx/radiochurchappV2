import { Navigate, Outlet } from "react-router-dom"
import { useAuthStore } from "../store/authStore"

const PublicRoute = () => {
  const { isAuthenticated } = useAuthStore()

  // If authenticated, redirect from public routes like login/register to home
  if (isAuthenticated) {
    return <Navigate to="/" replace />
  }

  return <Outlet />
}

export default PublicRoute
