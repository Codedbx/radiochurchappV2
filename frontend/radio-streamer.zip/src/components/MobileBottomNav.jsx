"use client"
import { Link, useLocation } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Home, LayoutGrid, Search, Users, User } from "lucide-react"

const MobileBottomNav = () => {
  const location = useLocation()

  const navItems = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/categories", icon: LayoutGrid, label: "Categories" },
    { path: "/search", icon: Search, label: "Search" },
    { path: "/library", icon: Users, label: "Library" },
    { path: "/profile", icon: User, label: "Profile" },
  ]

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white/95 dark:bg-slate-900/95 backdrop-blur-sm border-t border-slate-200 dark:border-slate-700 md:hidden">
      <div className="flex h-16 items-center justify-around">
        {navItems.map((item) => (
          <Button
            key={item.path}
            asChild
            variant="ghost"
            className={`flex flex-col gap-1 h-full rounded-none text-xs transition-colors ${
              location.pathname === item.path
                ? "text-primary bg-primary/10"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            }`}
          >
            <Link to={item.path}>
              <item.icon className="h-5 w-5" />
              {item.label}
            </Link>
          </Button>
        ))}
      </div>
    </nav>
  )
}

export default MobileBottomNav
