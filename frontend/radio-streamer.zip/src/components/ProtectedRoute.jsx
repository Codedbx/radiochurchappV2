import { Navigate, Outlet } from "react-router-dom"
import { useAuthStore } from "../store/authStore"

const ProtectedRoute = ({ allowedRoles = [] }) => {
  const { isAuthenticated, user } = useAuthStore()

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />
  }

  // Optional: Role-based access control
  if (allowedRoles.length > 0 && (!user || !allowedRoles.includes(user.role))) {
    // Redirect to an unauthorized page or home
    return <Navigate to="/" replace />
  }

  return <Outlet />
}

export default ProtectedRoute
