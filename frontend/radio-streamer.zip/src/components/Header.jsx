"use client"
import { Link, useNavigate } from "react-router-dom"
import React from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useAuthStore } from "../store/authStore"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Search, Menu, X } from "lucide-react"
import { ThemeToggle } from "@/components/ThemeToggle"
import authService from "../services/authServices"

const Header = () => {
  const { isAuthenticated, user } = useAuthStore()
  const navigate = useNavigate()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false)

  const handleLogout = async () => {
    await authService.logout()
    navigate("/login")
  }

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200/50 bg-white/95 backdrop-blur-xl dark:border-slate-700/50 dark:bg-slate-900/95">
      <div className="container mx-auto flex max-w-[90rem] font-medium text-slate-600 dark:text-foreground items-center justify-between px-4 py-3">
        {/* Logo - Always visible */}
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-8 w-8 md:h-10 md:w-10 items-center justify-center rounded-full">
            <img src="/images/loveworld-logo.png" className="rounded-full" alt="loveworld logo" />
          </div>
          <div className="hidden sm:block">
            <h1 className="text-lg font-bold">Online Radio Church</h1>
            <p className="text-sm text-slate-600 dark:text-slate-400">Broadcasting live</p>
          </div>
          <div className="block sm:hidden">
            <h1 className="text-base font-bold">Radio Church</h1>
          </div>
        </Link>

        {/* Desktop Navigation - Hidden on mobile */}
        <div className="hidden md:flex items-center space-x-8">
          <Link to="/" className="text-primary hover:text-primary transition-colors">
            Home
          </Link>
          <Link to="/messages" className="hover:text-primary transition-colors">
            Messages
          </Link>
          <Link to="/podcasts" className="hover:text-primary transition-colors">
            Podcasts
          </Link>
        </div>

        {/* Desktop Right Side - Hidden on mobile */}
        <nav className="hidden md:flex items-center space-x-4">
          <div className="relative w-sm h-12 max-w-full">
            <Input
              type="search"
              placeholder="Search messages, podcasts..."
              className="pl-8 pr-2 py-1 w-full h-full rounded-md text-sm text-slate-900 dark:text-white bg-white dark:bg-slate-800 placeholder:font-normal placeholder:text-slate-400 dark:placeholder:text-slate-500 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring focus:ring-purple-700"
            />
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500 dark:text-slate-400" />
          </div>
          {isAuthenticated ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user?.avatar || "/placeholder-user.jpg"} alt={user?.name || "User"} />
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      {user?.name ? user.name.charAt(0) : "U"}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{user?.name || "User"}</p>
                    <p className="text-xs leading-none text-muted-foreground">{user?.email || "user@example.com"}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate("/profile")}>Profile</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>Log out</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <>
              <Button asChild variant="secondary" className="dark:bg-slate-800">
                <Link to="/login">Login</Link>
              </Button>
              <Button asChild className="bg-purple-700 hover:bg-purple-800 text-white">
                <Link to="/register">Create free account</Link>
              </Button>
            </>
          )}
          <ThemeToggle />
        </nav>

        {/* Mobile Right Side - Theme toggle and menu */}
        <div className="md:hidden flex items-center gap-2">
          <ThemeToggle />
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="h-8 w-8"
          >
            {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile Menu Content */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl py-4 px-4 space-y-3 border-t border-slate-200/50 dark:border-slate-700/50">
          <div className="relative">
            <Input
              type="search"
              placeholder="Search..."
              className="pl-8 pr-2 py-2 rounded-md text-sm text-slate-900 dark:text-white bg-slate-50 dark:bg-slate-800 placeholder:text-slate-400 dark:placeholder:text-slate-500 border border-slate-300 dark:border-slate-600 focus:outline-none focus:ring-2 focus:ring-purple-700 w-full"
            />
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500 dark:text-slate-400" />
          </div>
          <div className="space-y-2">
            <Link
              to="/"
              className="block py-2 px-3 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              to="/messages"
              className="block py-2 px-3 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Messages
            </Link>
            <Link
              to="/podcasts"
              className="block py-2 px-3 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Podcasts
            </Link>
          </div>
          {isAuthenticated ? (
            <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-700">
              <Link
                to="/profile"
                className="block py-2 px-3 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Profile
              </Link>
              <Button
                variant="ghost"
                className="w-full justify-start py-2 px-3 text-left"
                onClick={() => {
                  handleLogout()
                  setIsMobileMenuOpen(false)
                }}
              >
                Log out
              </Button>
            </div>
          ) : (
            <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-700">
              <Button asChild variant="secondary" className="w-full">
                <Link to="/login" onClick={() => setIsMobileMenuOpen(false)}>
                  Login
                </Link>
              </Button>
              <Button asChild className="w-full bg-purple-700 hover:bg-purple-800 text-white">
                <Link to="/register" onClick={() => setIsMobileMenuOpen(false)}>
                  Create Account
                </Link>
              </Button>
            </div>
          )}
        </div>
      )}
    </header>
  )
}

export default Header
