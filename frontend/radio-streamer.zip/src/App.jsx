"use client"
import { useEffect, useState } from "react"
import { Routes, Route } from "react-router-dom"
import { useAuthStore } from "./store/authStore"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/sonner"
import { WifiOff } from "lucide-react"

// Layout Components
import Header from "./components/Header.jsx"
import MobileBottomNav from "./components/MobileBottomNav.jsx"

// Page Components
import HomePage from "./pages/HomePage.jsx"
import LoginPage from "./pages/auth/LoginPage.jsx"
import RegisterPage from "./pages/auth/RegisterPage.jsx"
import MessagesPage from "./pages/messages/MessagesPage.jsx"
import MessageDetailPage from "./pages/messages/MessageDetailPage.jsx"
import PodcastsPage from "./pages/podcasts/PodcastsPage.jsx"
import PodcastDetailPage from "./pages/podcasts/PodcastDetailPage.jsx"
import PlaylistsPage from "./pages/playlists/PlaylistsPage.jsx"
import PlaylistDetailPage from "./pages/playlists/PlaylistDetailPage.jsx"
import SearchPage from "./pages/SearchPage.jsx"
import CategoriesPage from "./pages/CategoriesPage.jsx"
import FavouritesPage from "./pages/FavouritesPage.jsx"
import ProfilePage from "./pages/ProfilePage.jsx"
import NotFoundPage from "./pages/NotFoundPage.jsx"

// Route Guards
import ProtectedRoute from "./components/ProtectedRoute.jsx"
import PublicRoute from "./components/PublicRoute.jsx"
import authService from "./services/authServices"
function App() {
  const initializeAuth = useAuthStore((state) => state.initializeAuth)
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated)
  const setUser = useAuthStore((state) => state.setUser)
  const [isOnline, setIsOnline] = useState(navigator.onLine)

  useEffect(() => {
    initializeAuth()
    if (isAuthenticated) {
      authService.fetchUser().catch(() => {
        useAuthStore.getState().logout()
      })
    }

    // Event listeners for online/offline status
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)

    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    return () => {
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)
    }
  }, [initializeAuth, isAuthenticated, setUser])

  return (
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
        <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 via-white to-blue-50/30 dark:from-slate-900 dark:via-slate-800 dark:to-violet-900/20">
          {/* "No internet connection" banner */}
          {!isOnline && (
            <div className="bg-red-500 text-white text-center py-2 flex items-center justify-center gap-2 text-sm z-50">
              <WifiOff className="h-4 w-4" /> No internet connection
            </div>
          )}

          <Header />

          <main className="flex-1 pb-16 md:pb-0">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/messages" element={<MessagesPage />} />
              <Route path="/messages/:id" element={<MessageDetailPage />} />
              <Route path="/podcasts" element={<PodcastsPage />} />
              <Route path="/podcasts/:id" element={<PodcastDetailPage />} />
              <Route path="/playlists" element={<PlaylistsPage />} />
              <Route path="/playlists/:id" element={<PlaylistDetailPage />} />
              <Route path="/search" element={<SearchPage />} />
              <Route path="/categories" element={<CategoriesPage />} />

              <Route element={<PublicRoute />}>
                <Route path="/login" element={<LoginPage />} />
                <Route path="/register" element={<RegisterPage />} />
              </Route>

              <Route element={<PublicRoute />}>
                <Route path="/favourites" element={<FavouritesPage />} />
                <Route path="/profile" element={<ProfilePage />} />
              </Route>

              <Route path="*" element={<NotFoundPage />} />
            </Routes>
          </main>

          {/* Mobile Bottom Navigation - Only show on mobile */}
          <div className="lg:hidden">
            <MobileBottomNav />
          </div>

          <Toaster
            theme="system"
            position="top-right"
            toastOptions={{
              style: {
                background: "hsl(var(--background))",
                color: "hsl(var(--foreground))",
                border: "1px solid hsl(var(--border))",
              },
            }}
          />
        </div>
      </ThemeProvider>
  )
}

export default App
