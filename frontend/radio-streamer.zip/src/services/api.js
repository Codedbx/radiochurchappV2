import config from "../config" // Import the new config file
import { LOCAL_STORAGE_TOKEN_KEY } from "../utils/constants"

const api = {
  get: async (path, config = {}) => {
    return await request("GET", path, null, config)
  },
  post: async (path, data, config = {}) => {
    return await request("POST", path, data, config)
  },
  put: async (path, data, config = {}) => {
    return await request("PUT", path, data, config)
  },
  delete: async (path, config = {}) => {
    return await request("DELETE", path, null, config)
  },
}

async function request(method, path, data = null, configOptions = {}) {
  // Renamed config to configOptions to avoid conflict
  const token = localStorage.getItem(LOCAL_STORAGE_TOKEN_KEY)
  const headers = {
    "Content-Type": "application/json",
    Accept: "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
    ...configOptions.headers,
  }

  const options = {
    method,
    headers,
    ...(data && { body: JSON.stringify(data) }),
    ...configOptions,
  }

  try {
    const response = await fetch(`${config.API_BASE_URL}${path}`, options) // Use config.API_BASE_URL

    if (!response.ok) {
      const errorData = await response.json()
      throw new Error(errorData.message || "Something went wrong")
    }

    const contentType = response.headers.get("content-type")
    if (contentType && contentType.includes("application/json")) {
      return await response.json()
    } else {
      return response.text()
    }
  } catch (error) {
    console.error("API request failed:", error)
    throw error
  }
}

export default api
