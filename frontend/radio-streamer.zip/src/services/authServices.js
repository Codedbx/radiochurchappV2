import api from "./api"
import { useAuthStore } from "../store/authStore"
import { toast } from "sonner" // Assuming shadcn/ui sonner for toasts

const authService = {
  login: async (credentials) => {
    try {
      const response = await api.post("/login", credentials)
      useAuthStore.getState().setToken(response.token) // Assuming API returns { token: '...' }
      // Optionally fetch user details here and set them
      toast.success("Logged in successfully!")
      return response
    } catch (error) {
      toast.error(error.message || "Login failed.")
      throw error
    }
  },

  register: async (userData) => {
    try {
      const response = await api.post("/register", userData)
      toast.success("Registration successful! Please verify your email.")
      return response
    } catch (error) {
      toast.error(error.message || "Registration failed.")
      throw error
    }
  },

  logout: async () => {
    try {
      await api.post("/logout") // Assuming a logout endpoint
      useAuthStore.getState().logout()
      toast.info("Logged out.")
    } catch (error) {
      toast.error(error.message || "Logout failed.")
      throw error
    }
  },

  // Add other auth methods like verifyEmail, forgotPassword, resetPassword
  verifyEmail: async (data) => {
    try {
      const response = await api.post("/email/verify", data)
      toast.success("Email verified successfully!")
      return response
    } catch (error) {
      toast.error(error.message || "Email verification failed.")
      throw error
    }
  },

  forgotPassword: async (email) => {
    try {
      const response = await api.post("/forgot-password", { email })
      toast.success("Password reset link sent to your email!")
      return response
    } catch (error) {
      toast.error(error.message || "Failed to send reset link.")
      throw error
    }
  },

  resetPassword: async (data) => {
    try {
      const response = await api.post("/reset-password", data)
      toast.success("Password has been reset successfully!")
      return response
    } catch (error) {
      toast.error(error.message || "Failed to reset password.")
      throw error
    }
  },

  // Fetch authenticated user details
  fetchUser: async () => {
    try {
      const response = await api.get("/user") // Assuming an endpoint to get current user
      useAuthStore.getState().setUser(response.user)
      return response.user
    } catch (error) {
      console.error("Failed to fetch user:", error)
      useAuthStore.getState().logout() // Log out if user token is invalid
      throw error
    }
  },
}

export default authService
