import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import api from "../services/api"
import { toast } from "sonner"
import config from "../config" // Import the config file

// Fetch all messages
export const useMessages = (params) => {
  return useQuery({
    queryKey: ["messages", params],
    queryFn: async () => {
      const queryString = new URLSearchParams(params).toString()
      const response = await api.get(`/messages?${queryString}`)
      return response.data // Assuming API returns { data: [...], meta: {...} }
    },
    staleTime: config.ENABLE_CACHING ? config.CACHE_TIMEOUT : 0, // Use config for staleTime
  })
}

// Fetch a single message by ID
export const useMessage = (id) => {
  return useQuery({
    queryKey: ["message", id],
    queryFn: async () => {
      const response = await api.get(`/messages/${id}`)
      return response.data // Assuming API returns { data: {...} }
    },
    enabled: !!id, // Only run query if ID is available
    staleTime: config.ENABLE_CACHING ? config.CACHE_TIMEOUT : 0, // Use config for staleTime
  })
}

// Add a comment to a message
export const useAddMessageComment = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: async ({ messageId, commentData }) => {
      const response = await api.post(`/messages/${messageId}/comments`, commentData)
      return response.data
    },
    onSuccess: (data, variables) => {
      toast.success("Comment added successfully!")
      queryClient.invalidateQueries(["message", variables.messageId])
      queryClient.setQueryData(["message", variables.messageId], (oldData) => {
        if (oldData) {
          return {
            ...oldData,
            comments: [...(oldData.comments || []), data],
          }
        }
        return oldData
      })
    },
    onError: (error) => {
      toast.error(error.message || "Failed to add comment.")
    },
  })
}

// Toggle message favourite status
export const useToggleMessageFavourite = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: async ({ messageId }) => {
      const response = await api.post(`/messages/${messageId}/favourite`)
      return response.data
    },
    onSuccess: (data, variables) => {
      toast.success(data.message)
      queryClient.invalidateQueries(["message", variables.messageId])
      queryClient.invalidateQueries(["favourites"])
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update favourite status.")
    },
  })
}
