import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import api from "../services/api"

// Hook to fetch all podcasts
export const usePodcasts = (params = {}) => {
  return useQuery({
    queryKey: ["podcasts", params],
    queryFn: () => api.get("/podcasts", { params }),
    staleTime: 5 * 60 * 1000, // 5 minutes
  })
}

// Hook to fetch a single podcast
export const usePodcast = (id) => {
  return useQuery({
    queryKey: ["podcast", id],
    queryFn: () => api.get(`/podcasts/${id}`),
    enabled: !!id,
    staleTime: 5 * 60 * 1000,
  })
}

// Hook to subscribe to a podcast
export const useSubscribeToPodcast = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: ({ podcastId }) => api.post(`/podcasts/${podcastId}/subscribe`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["podcasts"] })
      queryClient.invalidateQueries({ queryKey: ["user", "subscriptions"] })
    },
  })
}

// Hook to unsubscribe from a podcast
export const useUnsubscribeFromPodcast = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: ({ podcastId }) => api.delete(`/podcasts/${podcastId}/subscribe`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["podcasts"] })
      queryClient.invalidateQueries({ queryKey: ["user", "subscriptions"] })
    },
  })
}

// Hook to get user's subscribed podcasts
export const useSubscribedPodcasts = () => {
  return useQuery({
    queryKey: ["user", "subscriptions", "podcasts"],
    queryFn: () => api.get("/user/subscriptions/podcasts"),
    staleTime: 5 * 60 * 1000,
  })
}

// Hook to add podcast episode comment
export const useAddPodcastComment = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: ({ episodeId, commentData }) => api.post(`/podcast-episodes/${episodeId}/comments`, commentData),
    onSuccess: (_, { episodeId }) => {
      queryClient.invalidateQueries({ queryKey: ["podcast-episode", episodeId, "comments"] })
    },
  })
}
