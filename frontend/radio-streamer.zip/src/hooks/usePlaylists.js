import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import api from "../services/api"

// Hook to fetch all playlists
export const usePlaylists = (params = {}) => {
  return useQuery({
    queryKey: ["playlists", params],
    queryFn: () => api.get("/playlists", { params }),
    staleTime: 5 * 60 * 1000,
  })
}

// Hook to fetch a single playlist
export const usePlaylist = (id) => {
  return useQuery({
    queryKey: ["playlist", id],
    queryFn: () => api.get(`/playlists/${id}`),
    enabled: !!id,
    staleTime: 5 * 60 * 1000,
  })
}

// Hook to create a new playlist
export const useCreatePlaylist = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (playlistData) => api.post("/playlists", playlistData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["playlists"] })
      queryClient.invalidateQueries({ queryKey: ["user", "playlists"] })
    },
  })
}

// Hook to update a playlist
export const useUpdatePlaylist = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: ({ id, playlistData }) => api.put(`/playlists/${id}`, playlistData),
    onSuccess: (_, { id }) => {
      queryClient.invalidateQueries({ queryKey: ["playlist", id] })
      queryClient.invalidateQueries({ queryKey: ["playlists"] })
    },
  })
}

// Hook to delete a playlist
export const useDeletePlaylist = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (id) => api.delete(`/playlists/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["playlists"] })
      queryClient.invalidateQueries({ queryKey: ["user", "playlists"] })
    },
  })
}

// Hook to add message to playlist
export const useAddToPlaylist = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: ({ playlistId, messageId }) => api.post(`/playlists/${playlistId}/messages`, { messageId }),
    onSuccess: (_, { playlistId }) => {
      queryClient.invalidateQueries({ queryKey: ["playlist", playlistId] })
    },
  })
}

// Hook to remove message from playlist
export const useRemoveFromPlaylist = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: ({ playlistId, messageId }) => api.delete(`/playlists/${playlistId}/messages/${messageId}`),
    onSuccess: (_, { playlistId }) => {
      queryClient.invalidateQueries({ queryKey: ["playlist", playlistId] })
    },
  })
}

// Hook to get user's playlists
export const useUserPlaylists = () => {
  return useQuery({
    queryKey: ["user", "playlists"],
    queryFn: () => api.get("/user/playlists"),
    staleTime: 5 * 60 * 1000,
  })
}
