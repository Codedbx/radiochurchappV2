import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import api from "../services/api"

// Hook to get user's favorites
export const useFavorites = (type = "all") => {
  return useQuery({
    queryKey: ["user", "favorites", type],
    queryFn: () => api.get(`/user/favorites?type=${type}`),
    staleTime: 5 * 60 * 1000,
  })
}

// Hook to add to favorites
export const useAddToFavorites = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: ({ type, id }) => api.post("/user/favorites", { type, id }),
    onSuccess: (_, { type }) => {
      queryClient.invalidateQueries({ queryKey: ["user", "favorites"] })
      queryClient.invalidateQueries({ queryKey: ["user", "favorites", type] })
      queryClient.invalidateQueries({ queryKey: ["user", "favorites", "all"] })
    },
  })
}

// Hook to remove from favorites
export const useRemoveFromFavorites = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: ({ type, id }) => api.delete(`/user/favorites/${type}/${id}`),
    onSuccess: (_, { type }) => {
      queryClient.invalidateQueries({ queryKey: ["user", "favorites"] })
      queryClient.invalidateQueries({ queryKey: ["user", "favorites", type] })
      queryClient.invalidateQueries({ queryKey: ["user", "favorites", "all"] })
    },
  })
}

// Hook to check if item is favorited
export const useIsFavorited = (type, id) => {
  return useQuery({
    queryKey: ["user", "favorites", "check", type, id],
    queryFn: () => api.get(`/user/favorites/check/${type}/${id}`),
    enabled: !!(type && id),
    staleTime: 5 * 60 * 1000,
  })
}

// Hook to toggle favorite status
export const useToggleFavorite = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: ({ type, id, isFavorited }) => {
      if (isFavorited) {
        return api.delete(`/user/favorites/${type}/${id}`)
      } else {
        return api.post("/user/favorites", { type, id })
      }
    },
    onSuccess: (_, { type }) => {
      queryClient.invalidateQueries({ queryKey: ["user", "favorites"] })
      queryClient.invalidateQueries({ queryKey: ["user", "favorites", type] })
      queryClient.invalidateQueries({ queryKey: ["user", "favorites", "all"] })
      queryClient.invalidateQueries({ queryKey: ["user", "favorites", "check"] })
    },
  })
}
