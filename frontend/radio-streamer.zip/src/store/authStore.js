import { create } from "zustand"
import { LOCAL_STORAGE_TOKEN_KEY } from "../utils/constants"

export const useAuthStore = create((set) => ({
  token: localStorage.getItem(LOCAL_STORAGE_TOKEN_KEY) || null,
  user: null, // You might fetch user details after login
  isAuthenticated: !!localStorage.getItem(LOCAL_STORAGE_TOKEN_KEY),

  setToken: (token) => {
    localStorage.setItem(LOCAL_STORAGE_TOKEN_KEY, token)
    set({ token, isAuthenticated: true })
  },
  setUser: (user) => set({ user }),
  logout: () => {
    localStorage.removeItem(LOCAL_STORAGE_TOKEN_KEY)
    set({ token: null, user: null, isAuthenticated: false })
  },
  // Function to initialize auth state from local storage on app load
  initializeAuth: () => {
    const token = localStorage.getItem(LOCAL_STORAGE_TOKEN_KEY)
    if (token) {
      set({ token, isAuthenticated: true })
      // Optionally fetch user details here if token exists
      // For example: fetchUser(token).then(user => set({ user }));
    }
  },
}))
