export const LOCAL_STORAGE_TOKEN_KEY = "laravel_sanctum_token"
